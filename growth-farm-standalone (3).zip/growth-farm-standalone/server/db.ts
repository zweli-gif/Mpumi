import { eq, and, desc, asc, gte, lte, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/better-sqlite3";
import Database from "better-sqlite3";
import { 
  InsertUser, 
  users,
  healthCheckins,
  InsertHealthCheckin,
  weeklyPriorities,
  InsertWeeklyPriority,
  celebrations,
  InsertCelebration,
  pipelineStages,
  InsertPipelineStage,
  pipelineCards,
  InsertPipelineCard,
  annualGoals,
  InsertAnnualGoal,
  monthlyTargets,
  InsertMonthlyTarget,
  performanceSnapshots,
  InsertPerformanceSnapshot,
  insights,
  InsertInsight,
  activityLog,
  InsertActivityLog,
  dashboardMetrics,
  InsertDashboardMetric,
  systemSettings,
  InsertSystemSetting,
  ceoReflections,
  InsertCeoReflection
} from "./schema";

// Create SQLite database
const sqlite = new Database("growth-farm.db");
export const db = drizzle(sqlite);

// ============================================================================
// USER MANAGEMENT
// ============================================================================

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const existing = await getUserByOpenId(user.openId);
  
  if (existing) {
    await db.update(users)
      .set({
        name: user.name ?? existing.name,
        email: user.email ?? existing.email,
        avatarUrl: user.avatarUrl ?? existing.avatarUrl,
        role: user.role ?? existing.role,
        lastSignedIn: new Date(),
        updatedAt: new Date(),
      })
      .where(eq(users.openId, user.openId));
  } else {
    await db.insert(users).values({
      ...user,
      lastSignedIn: new Date(),
      createdAt: new Date(),
      updatedAt: new Date(),
    });
  }
}

export async function getUserByOpenId(openId: string) {
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getUserById(userId: number) {
  const result = await db.select().from(users).where(eq(users.id, userId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getAllUsers() {
  return db.select().from(users).orderBy(asc(users.name));
}

export async function updateUser(userId: number, data: { name?: string; email?: string; role?: "user" | "admin"; jobTitle?: string }) {
  await db.update(users)
    .set({ ...data, updatedAt: new Date() })
    .where(eq(users.id, userId));
  return getUserById(userId);
}

export async function deleteUser(userId: number) {
  await db.delete(users).where(eq(users.id, userId));
  return true;
}

export async function createInvitedUser(data: { name: string; email: string; role?: "user" | "admin"; jobTitle?: string }) {
  const openId = `invited_${Date.now()}_${Math.random().toString(36).substring(7)}`;
  const result = await db.insert(users).values({
    openId,
    name: data.name,
    email: data.email,
    role: data.role || "user",
    jobTitle: data.jobTitle,
    loginMethod: "invited",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  }).returning({ id: users.id });
  return { id: result[0].id, openId, ...data };
}

export async function updateUserHealth(userId: number, healthScore: number, energyLevel: "High" | "Med" | "Low") {
  await db.update(users)
    .set({ currentHealthScore: healthScore, currentEnergyLevel: energyLevel, updatedAt: new Date() })
    .where(eq(users.id, userId));
}

// ============================================================================
// HEALTH CHECK-INS
// ============================================================================

export async function createHealthCheckin(checkin: InsertHealthCheckin) {
  const result = await db.insert(healthCheckins).values({
    ...checkin,
    createdAt: new Date(),
  }).returning({ id: healthCheckins.id });
  
  // Update user's current health score
  await updateUserHealth(checkin.userId, checkin.score, checkin.energyLevel);
  
  return result[0];
}

export async function getRecentHealthCheckins(userId: number, limit: number = 10) {
  return db.select()
    .from(healthCheckins)
    .where(eq(healthCheckins.userId, userId))
    .orderBy(desc(healthCheckins.checkinDate))
    .limit(limit);
}

export async function getTeamHealthOverview() {
  return db.select({
    userId: users.id,
    name: users.name,
    email: users.email,
    avatarUrl: users.avatarUrl,
    jobTitle: users.jobTitle,
    currentHealthScore: users.currentHealthScore,
    currentEnergyLevel: users.currentEnergyLevel,
  }).from(users);
}

// ============================================================================
// WEEKLY PRIORITIES
// ============================================================================

export async function createWeeklyPriority(priority: InsertWeeklyPriority) {
  const result = await db.insert(weeklyPriorities).values({
    ...priority,
    createdAt: new Date(),
    updatedAt: new Date(),
  }).returning({ id: weeklyPriorities.id });
  return result[0];
}

export async function getWeeklyPriorities(weekNumber: number, year: number) {
  return db.select()
    .from(weeklyPriorities)
    .where(and(
      eq(weeklyPriorities.weekNumber, weekNumber),
      eq(weeklyPriorities.year, year)
    ))
    .orderBy(asc(weeklyPriorities.dueDate));
}

export async function getUserWeeklyPriorities(userId: number, weekNumber: number, year: number) {
  return db.select()
    .from(weeklyPriorities)
    .where(and(
      eq(weeklyPriorities.userId, userId),
      eq(weeklyPriorities.weekNumber, weekNumber),
      eq(weeklyPriorities.year, year)
    ))
    .orderBy(asc(weeklyPriorities.dueDate));
}

export async function updateWeeklyPriority(id: number, updates: Partial<InsertWeeklyPriority>) {
  await db.update(weeklyPriorities)
    .set({ ...updates, updatedAt: new Date() })
    .where(eq(weeklyPriorities.id, id));
  return { id };
}

export async function deleteWeeklyPriority(id: number) {
  await db.delete(weeklyPriorities).where(eq(weeklyPriorities.id, id));
  return { id };
}

// ============================================================================
// CELEBRATIONS
// ============================================================================

export async function createCelebration(celebration: InsertCelebration) {
  const result = await db.insert(celebrations).values({
    ...celebration,
    createdAt: new Date(),
  }).returning({ id: celebrations.id });
  return result[0];
}

export async function getRecentCelebrations(limit: number = 20) {
  return db.select()
    .from(celebrations)
    .orderBy(desc(celebrations.celebrationDate))
    .limit(limit);
}

export async function deleteCelebration(id: number) {
  await db.delete(celebrations).where(eq(celebrations.id, id));
  return { id };
}

// ============================================================================
// PIPELINES
// ============================================================================

export async function getPipelineStages(pipelineType: string) {
  return db.select()
    .from(pipelineStages)
    .where(eq(pipelineStages.pipelineType, pipelineType as any))
    .orderBy(asc(pipelineStages.order));
}

export async function getPipelineCards(pipelineType: string) {
  const stages = await getPipelineStages(pipelineType);
  const stageIds = stages.map(s => s.id);
  
  if (stageIds.length === 0) return { stages, cards: [] };
  
  const cards = await db.select()
    .from(pipelineCards)
    .where(sql`${pipelineCards.stageId} IN (${sql.join(stageIds.map(id => sql`${id}`), sql`, `)})`)
    .orderBy(asc(pipelineCards.position));
  
  return { stages, cards };
}

export async function createPipelineCard(card: InsertPipelineCard) {
  const result = await db.insert(pipelineCards).values({
    ...card,
    createdAt: new Date(),
    updatedAt: new Date(),
  }).returning({ id: pipelineCards.id });
  return result[0];
}

export async function updatePipelineCard(id: number, updates: Partial<InsertPipelineCard>) {
  await db.update(pipelineCards)
    .set({ ...updates, updatedAt: new Date() })
    .where(eq(pipelineCards.id, id));
  return { id };
}

export async function deletePipelineCard(id: number) {
  await db.delete(pipelineCards).where(eq(pipelineCards.id, id));
  return { id };
}

export async function movePipelineCard(id: number, stageId: number, position: number) {
  await db.update(pipelineCards)
    .set({ stageId, position, movedAt: new Date(), updatedAt: new Date() })
    .where(eq(pipelineCards.id, id));
  return { id };
}

// ============================================================================
// ANNUAL GOALS
// ============================================================================

export async function createAnnualGoal(goal: InsertAnnualGoal) {
  const result = await db.insert(annualGoals).values({
    ...goal,
    createdAt: new Date(),
    updatedAt: new Date(),
  }).returning({ id: annualGoals.id });
  return result[0];
}

export async function getAnnualGoals(year: number) {
  return db.select()
    .from(annualGoals)
    .where(eq(annualGoals.year, year))
    .orderBy(asc(annualGoals.category));
}

export async function updateAnnualGoal(id: number, updates: Partial<InsertAnnualGoal>) {
  await db.update(annualGoals)
    .set({ ...updates, updatedAt: new Date() })
    .where(eq(annualGoals.id, id));
  return { id };
}

export async function deleteAnnualGoal(id: number) {
  await db.delete(annualGoals).where(eq(annualGoals.id, id));
  return { id };
}

// ============================================================================
// MONTHLY TARGETS
// ============================================================================

export async function createMonthlyTarget(target: InsertMonthlyTarget) {
  const result = await db.insert(monthlyTargets).values({
    ...target,
    createdAt: new Date(),
    updatedAt: new Date(),
  }).returning({ id: monthlyTargets.id });
  return result[0];
}

export async function getMonthlyTargets(goalId: number) {
  return db.select()
    .from(monthlyTargets)
    .where(eq(monthlyTargets.goalId, goalId))
    .orderBy(asc(monthlyTargets.month));
}

export async function getMonthlyTargetsByMonth(month: number, year: number) {
  return db.select()
    .from(monthlyTargets)
    .where(and(
      eq(monthlyTargets.month, month),
      eq(monthlyTargets.year, year)
    ));
}

export async function updateMonthlyTarget(id: number, updates: Partial<InsertMonthlyTarget>) {
  await db.update(monthlyTargets)
    .set({ ...updates, updatedAt: new Date() })
    .where(eq(monthlyTargets.id, id));
  return { id };
}

export async function bulkCreateMonthlyTargets(targets: InsertMonthlyTarget[]) {
  const result = await db.insert(monthlyTargets).values(targets.map(t => ({
    ...t,
    createdAt: new Date(),
    updatedAt: new Date(),
  }))).returning({ id: monthlyTargets.id });
  return result;
}

// ============================================================================
// ACTIVITY LOG
// ============================================================================

export async function logActivity(activity: InsertActivityLog) {
  const result = await db.insert(activityLog).values({
    ...activity,
    createdAt: new Date(),
  }).returning({ id: activityLog.id });
  return result[0];
}

export async function getRecentActivity(limit: number = 50) {
  return db.select()
    .from(activityLog)
    .orderBy(desc(activityLog.timestamp))
    .limit(limit);
}

export async function getActivityByEntity(entityType: string, entityId: number) {
  return db.select()
    .from(activityLog)
    .where(and(
      eq(activityLog.entityType, entityType),
      eq(activityLog.entityId, entityId)
    ))
    .orderBy(desc(activityLog.timestamp));
}

// ============================================================================
// CEO REFLECTIONS
// ============================================================================

export async function getCeoReflection(weekNumber: number, year: number) {
  const result = await db.select()
    .from(ceoReflections)
    .where(and(
      eq(ceoReflections.weekNumber, weekNumber),
      eq(ceoReflections.year, year)
    ))
    .limit(1);
  
  return result.length > 0 ? result[0] : null;
}

export async function upsertCeoReflection(reflection: InsertCeoReflection) {
  const existing = await getCeoReflection(reflection.weekNumber, reflection.year);
  
  if (existing) {
    await db.update(ceoReflections)
      .set({ content: reflection.content, updatedAt: new Date() })
      .where(eq(ceoReflections.id, existing.id));
    return { id: existing.id };
  } else {
    const result = await db.insert(ceoReflections).values({
      ...reflection,
      createdAt: new Date(),
      updatedAt: new Date(),
    }).returning({ id: ceoReflections.id });
    return result[0];
  }
}
