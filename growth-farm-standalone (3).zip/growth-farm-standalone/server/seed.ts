import { db } from "./db";
import { users, pipelineStages, pipelineCards, annualGoals, celebrations, weeklyPriorities } from "./schema";

async function seed() {
  console.log("🌱 Seeding database...");

  // Clear existing data
  await db.delete(weeklyPriorities);
  await db.delete(celebrations);
  await db.delete(pipelineCards);
  await db.delete(pipelineStages);
  await db.delete(annualGoals);
  await db.delete(users);

  // Create admin user (CEO)
  const [admin] = await db.insert(users).values({
    openId: "admin_zweli",
    name: "Zweli Ntshona",
    email: "zweli@growthfarm.africa",
    role: "admin",
    jobTitle: "CEO & Founder",
    currentHealthScore: 85,
    currentEnergyLevel: "High",
    loginMethod: "email",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  }).returning({ id: users.id });

  // Create team members
  const teamMembers = [
    { name: "Albert Mokoena", email: "albert@growthfarm.africa", jobTitle: "Chief of Staff", score: 78 },
    { name: "Brian Dube", email: "brian@growthfarm.africa", jobTitle: "Chief of Staff Associate", score: 82 },
    { name: "Lindiwe Nkosi", email: "lindiwe@growthfarm.africa", jobTitle: "Fractional CFO", score: 75 },
    { name: "Thabo Molefe", email: "thabo@growthfarm.africa", jobTitle: "UX Design Lead", score: 88 },
    { name: "Naledi Khumalo", email: "naledi@growthfarm.africa", jobTitle: "Strategy Consultant", score: 72 },
  ];

  const insertedUsers = [{ id: admin.id }];
  
  for (const member of teamMembers) {
    const [user] = await db.insert(users).values({
      openId: `user_${member.email.replace(/[^a-zA-Z0-9]/g, '_')}`,
      name: member.name,
      email: member.email,
      role: "user",
      jobTitle: member.jobTitle,
      currentHealthScore: member.score,
      currentEnergyLevel: member.score >= 80 ? "High" : member.score >= 60 ? "Med" : "Low",
      loginMethod: "email",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    }).returning({ id: users.id });
    insertedUsers.push(user);
  }

  console.log(`✅ Created ${insertedUsers.length} users`);

  // Create BD Pipeline stages
  const bdStages = [
    { name: "Lead", order: 1, probabilityWeight: 10 },
    { name: "Discovery", order: 2, probabilityWeight: 25 },
    { name: "Proposal", order: 3, probabilityWeight: 50 },
    { name: "Negotiation", order: 4, probabilityWeight: 75 },
    { name: "Contracting", order: 5, probabilityWeight: 90 },
    { name: "Won", order: 6, probabilityWeight: 100 },
    { name: "Lost", order: 7, probabilityWeight: 0 },
  ];

  const bdStageIds: number[] = [];
  for (const stage of bdStages) {
    const [result] = await db.insert(pipelineStages).values({
      pipelineType: "bd",
      name: stage.name,
      order: stage.order,
      probabilityWeight: stage.probabilityWeight,
      createdAt: new Date(),
    }).returning({ id: pipelineStages.id });
    bdStageIds.push(result.id);
  }

  // Create Ventures Pipeline stages
  const ventureStages = [
    { name: "Ideation", order: 1 },
    { name: "Validation", order: 2 },
    { name: "MVP", order: 3 },
    { name: "Growth", order: 4 },
    { name: "Scale", order: 5 },
  ];

  const ventureStageIds: number[] = [];
  for (const stage of ventureStages) {
    const [result] = await db.insert(pipelineStages).values({
      pipelineType: "ventures",
      name: stage.name,
      order: stage.order,
      createdAt: new Date(),
    }).returning({ id: pipelineStages.id });
    ventureStageIds.push(result.id);
  }

  // Create Studio Pipeline stages
  const studioStages = [
    { name: "Scoping", order: 1 },
    { name: "Active", order: 2 },
    { name: "Review", order: 3 },
    { name: "Complete", order: 4 },
  ];

  const studioStageIds: number[] = [];
  for (const stage of studioStages) {
    const [result] = await db.insert(pipelineStages).values({
      pipelineType: "studio",
      name: stage.name,
      order: stage.order,
      createdAt: new Date(),
    }).returning({ id: pipelineStages.id });
    studioStageIds.push(result.id);
  }

  // Create Clients Pipeline stages
  const clientStages = [
    { name: "Prospect", order: 1 },
    { name: "Active", order: 2 },
    { name: "At Risk", order: 3 },
    { name: "Strategic Partner", order: 4 },
  ];

  const clientStageIds: number[] = [];
  for (const stage of clientStages) {
    const [result] = await db.insert(pipelineStages).values({
      pipelineType: "clients",
      name: stage.name,
      order: stage.order,
      createdAt: new Date(),
    }).returning({ id: pipelineStages.id });
    clientStageIds.push(result.id);
  }

  // Create Finance Pipeline stages
  const financeStages = [
    { name: "Pending", order: 1 },
    { name: "In Progress", order: 2 },
    { name: "Complete", order: 3 },
  ];

  for (const stage of financeStages) {
    await db.insert(pipelineStages).values({
      pipelineType: "finance",
      name: stage.name,
      order: stage.order,
      createdAt: new Date(),
    });
  }

  console.log("✅ Created pipeline stages");

  // Create BD Pipeline cards
  const bdCards = [
    { title: "IBM Accelerator Expansion", value: "5000000", stageIndex: 5, owner: 1 }, // Won
    { title: "Standard Bank Innovation Hub", value: "3500000", stageIndex: 2, owner: 1 }, // Proposal
    { title: "MTN Digital Services", value: "2800000", stageIndex: 1, owner: 2 }, // Discovery
    { title: "Vodacom Youth Platform", value: "4200000", stageIndex: 3, owner: 1 }, // Negotiation
    { title: "FNB SME Programme", value: "1800000", stageIndex: 0, owner: 3 }, // Lead
    { title: "Google for Startups Africa", value: "2500000", stageIndex: 2, owner: 2 }, // Proposal
  ];

  for (const card of bdCards) {
    await db.insert(pipelineCards).values({
      stageId: bdStageIds[card.stageIndex],
      title: card.title,
      value: card.value,
      currency: "ZAR",
      ownerId: insertedUsers[card.owner].id,
      position: 0,
      createdAt: new Date(),
      updatedAt: new Date(),
    });
  }

  // Create Venture cards
  const ventureCards = [
    { title: "Mntase! Communities", stageIndex: 2, description: "Community-powered acquisition platform" },
    { title: "briansfomo", stageIndex: 1, description: "Curator-hosted gatherings platform" },
    { title: "Mntase Living", stageIndex: 0, description: "Student to mining housing progression" },
  ];

  for (const card of ventureCards) {
    await db.insert(pipelineCards).values({
      stageId: ventureStageIds[card.stageIndex],
      title: card.title,
      description: card.description,
      position: 0,
      createdAt: new Date(),
      updatedAt: new Date(),
    });
  }

  // Create Studio cards
  const studioCards = [
    { title: "IBM Design Sprint - Wave 3", stageIndex: 1, value: "1200000" },
    { title: "Vodacom UX Audit", stageIndex: 0, value: "350000" },
  ];

  for (const card of studioCards) {
    await db.insert(pipelineCards).values({
      stageId: studioStageIds[card.stageIndex],
      title: card.title,
      value: card.value,
      currency: "ZAR",
      position: 0,
      createdAt: new Date(),
      updatedAt: new Date(),
    });
  }

  // Create Client cards
  const clientCards = [
    { title: "IBM", stageIndex: 3, value: "12000000" }, // Strategic Partner
    { title: "Vodacom", stageIndex: 1, value: "4200000" }, // Active
    { title: "Standard Bank", stageIndex: 0, value: "3500000" }, // Prospect
  ];

  for (const card of clientCards) {
    await db.insert(pipelineCards).values({
      stageId: clientStageIds[card.stageIndex],
      title: card.title,
      value: card.value,
      currency: "ZAR",
      position: 0,
      createdAt: new Date(),
      updatedAt: new Date(),
    });
  }

  console.log("✅ Created pipeline cards");

  // Create Annual Goals
  const goals = [
    { category: "revenue", description: "Annual Revenue", targetValue: "24000000", targetUnit: "ZAR" },
    { category: "revenue", description: "Cash Reserves (Dec)", targetValue: "1000000", targetUnit: "ZAR" },
    { category: "ventures", description: "Active Ventures", targetValue: "3", targetUnit: "count" },
    { category: "clients", description: "Strategic Partners", targetValue: "5", targetUnit: "count" },
    { category: "team", description: "Team Health Score", targetValue: "80", targetUnit: "percentage" },
  ];

  for (const goal of goals) {
    await db.insert(annualGoals).values({
      category: goal.category as any,
      description: goal.description,
      targetValue: goal.targetValue,
      targetUnit: goal.targetUnit,
      ownerId: admin.id,
      year: 2026,
      distributionStrategy: "linear",
      createdAt: new Date(),
      updatedAt: new Date(),
    });
  }

  console.log("✅ Created annual goals");

  // Create Celebrations
  const celebrationData = [
    { title: "IBM Contract Signed!", description: "R12M deal closed for 2026", category: "deal", icon: "🎉" },
    { title: "Happy Birthday Naledi!", description: "Wishing you all the best", category: "birthday", icon: "🎂" },
    { title: "Mntase! MVP Complete", description: "First version ready for testing", category: "milestone", icon: "🚀" },
    { title: "Team Retreat Success", description: "Amazing bonding session in Cape Town", category: "personal", icon: "❤️" },
  ];

  for (let i = 0; i < celebrationData.length; i++) {
    const cel = celebrationData[i];
    await db.insert(celebrations).values({
      title: cel.title,
      description: cel.description,
      category: cel.category as any,
      icon: cel.icon,
      celebrationDate: new Date(Date.now() - i * 3 * 24 * 60 * 60 * 1000), // Stagger dates
      createdBy: insertedUsers[i % insertedUsers.length].id,
      createdAt: new Date(),
    });
  }

  console.log("✅ Created celebrations");

  // Create Weekly Priorities
  const now = new Date();
  const weekNumber = Math.ceil((now.getTime() - new Date(now.getFullYear(), 0, 1).getTime()) / (7 * 24 * 60 * 60 * 1000));
  
  const priorities = [
    { userId: admin.id, description: "Finalize Mntase! MVP for demo", objective: "New Frontiers" },
    { userId: admin.id, description: "Review Q1 financial projections", objective: "Stewardship" },
    { userId: admin.id, description: "Prepare IBM stakeholder presentation", objective: "Impact Delivery" },
    { userId: insertedUsers[1].id, description: "Complete team health check process", objective: "Purpose & Platform" },
    { userId: insertedUsers[2].id, description: "Draft briansfomo launch plan", objective: "New Frontiers" },
  ];

  for (const priority of priorities) {
    await db.insert(weeklyPriorities).values({
      userId: priority.userId,
      description: priority.description,
      status: "pending",
      dueDate: new Date(now.getTime() + 5 * 24 * 60 * 60 * 1000),
      weekNumber,
      year: now.getFullYear(),
      strategicObjective: priority.objective,
      createdAt: new Date(),
      updatedAt: new Date(),
    });
  }

  console.log("✅ Created weekly priorities");
  console.log("🎉 Seeding complete!");
  
  console.log("\n📋 Login credentials:");
  console.log("   Admin: zweli@growthfarm.africa (Zweli Ntshona)");
  console.log("   User:  albert@growthfarm.africa (Albert Mokoena)");
}

seed().catch(console.error);
