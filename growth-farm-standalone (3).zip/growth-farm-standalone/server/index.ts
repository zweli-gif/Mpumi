import express from "express";
import cors from "cors";
import cookieParser from "cookie-parser";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { appRouter } from "./routers";
import { createContext } from "./context";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors({
  origin: process.env.NODE_ENV === "production" ? false : ["http://localhost:5173", "http://localhost:3000"],
  credentials: true,
}));
app.use(cookieParser());
app.use(express.json());

// tRPC API
app.use("/api/trpc", createExpressMiddleware({
  router: appRouter,
  createContext,
}));

// Serve static files in production
if (process.env.NODE_ENV === "production") {
  app.use(express.static(path.join(__dirname, "../dist/client")));
  app.get("*", (req, res) => {
    res.sendFile(path.join(__dirname, "../dist/client/index.html"));
  });
}

app.listen(PORT, () => {
  console.log(`🚀 Growth Farm server running at http://localhost:${PORT}`);
  console.log(`📊 tRPC API available at http://localhost:${PORT}/api/trpc`);
});

export type { AppRouter } from "./routers";
