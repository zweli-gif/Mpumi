import { z } from "zod";
import { TRPCError, initTRPC } from "@trpc/server";
import type { Context } from "./context";
import * as db from "./db";

// Helper to get current week number
function getWeekNumber(date: Date): number {
  const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
  const dayNum = d.getUTCDay() || 7;
  d.setUTCDate(d.getUTCDate() + 4 - dayNum);
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
  return Math.ceil((((d.getTime() - yearStart.getTime()) / 86400000) + 1) / 7);
}

const t = initTRPC.context<Context>().create();

export const router = t.router;
export const publicProcedure = t.procedure;

// Protected procedure that requires authentication
export const protectedProcedure = t.procedure.use(async ({ ctx, next }) => {
  if (!ctx.user) {
    throw new TRPCError({ code: "UNAUTHORIZED" });
  }
  return next({ ctx: { ...ctx, user: ctx.user } });
});

export const appRouter = router({
  auth: router({
    me: publicProcedure.query(({ ctx }) => ctx.user),
    
    // Simple login for dev/demo purposes
    login: publicProcedure
      .input(z.object({
        email: z.string().email(),
        name: z.string(),
        role: z.enum(["user", "admin"]).optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        const openId = `user_${input.email.replace(/[^a-zA-Z0-9]/g, '_')}`;
        await db.upsertUser({
          openId,
          email: input.email,
          name: input.name,
          role: input.role || "user",
          loginMethod: "email",
        });
        const user = await db.getUserByOpenId(openId);
        
        // Set cookie for session
        if (ctx.res) {
          ctx.res.cookie("auth_session", openId, {
            httpOnly: true,
            secure: process.env.NODE_ENV === "production",
            sameSite: "lax",
            maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days
          });
        }
        
        return user;
      }),
    
    logout: protectedProcedure.mutation(({ ctx }) => {
      if (ctx.res) {
        ctx.res.clearCookie("auth_session");
      }
      return { success: true };
    }),
  }),

  // ============================================================================
  // TEAM HEALTH
  // ============================================================================
  health: router({
    getTeamOverview: protectedProcedure.query(async () => {
      const team = await db.getTeamHealthOverview();
      const totalScore = team.reduce((sum, member) => sum + (member.currentHealthScore || 0), 0);
      const overallScore = team.length > 0 ? Math.round(totalScore / team.length) : 0;
      
      return { overallScore, team };
    }),

    submitCheckin: protectedProcedure
      .input(z.object({
        score: z.number().min(0).max(100),
        mood: z.enum(["happy", "neutral", "sad"]),
        energyLevel: z.enum(["High", "Med", "Low"]),
        notes: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const checkin = await db.createHealthCheckin({
          userId: ctx.user.id,
          score: input.score,
          mood: input.mood,
          energyLevel: input.energyLevel,
          notes: input.notes,
          checkinDate: new Date(),
        });

        await db.logActivity({
          userId: ctx.user.id,
          actionType: "health_checkin",
          entityType: "health_checkin",
          entityId: ctx.user.id,
          newValue: JSON.stringify({ score: input.score, mood: input.mood, energyLevel: input.energyLevel }),
          description: `${ctx.user.name} submitted health check-in: ${input.score}%`,
          timestamp: Date.now(),
        });

        return checkin;
      }),

    getMyCheckins: protectedProcedure
      .input(z.object({ limit: z.number().default(10) }))
      .query(async ({ ctx, input }) => {
        return db.getRecentHealthCheckins(ctx.user.id, input.limit);
      }),
  }),

  // ============================================================================
  // WEEKLY PRIORITIES
  // ============================================================================
  priorities: router({
    getCurrentWeek: protectedProcedure.query(async () => {
      const now = new Date();
      const weekNumber = getWeekNumber(now);
      const year = now.getFullYear();
      return db.getWeeklyPriorities(weekNumber, year);
    }),

    getMyPriorities: protectedProcedure.query(async ({ ctx }) => {
      const now = new Date();
      const weekNumber = getWeekNumber(now);
      const year = now.getFullYear();
      return db.getUserWeeklyPriorities(ctx.user.id, weekNumber, year);
    }),

    create: protectedProcedure
      .input(z.object({
        description: z.string().min(1),
        dueDate: z.date(),
        linkedGoalId: z.number().optional(),
        strategicObjective: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const weekNumber = getWeekNumber(input.dueDate);
        const year = input.dueDate.getFullYear();

        const existing = await db.getUserWeeklyPriorities(ctx.user.id, weekNumber, year);
        if (existing.length >= 5) {
          throw new TRPCError({
            code: "BAD_REQUEST",
            message: "Maximum 5 priorities per week allowed",
          });
        }

        const priority = await db.createWeeklyPriority({
          userId: ctx.user.id,
          description: input.description,
          dueDate: input.dueDate,
          weekNumber,
          year,
          linkedGoalId: input.linkedGoalId,
          strategicObjective: input.strategicObjective,
          status: "pending",
        });

        await db.logActivity({
          userId: ctx.user.id,
          actionType: "priority_added",
          entityType: "weekly_priority",
          entityId: ctx.user.id,
          newValue: JSON.stringify(input),
          description: `${ctx.user.name} added priority: ${input.description}`,
          timestamp: Date.now(),
        });

        return priority;
      }),

    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        description: z.string().optional(),
        status: z.enum(["pending", "in-progress", "done", "blocked"]).optional(),
        dueDate: z.date().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const { id, ...updates } = input;
        const result = await db.updateWeeklyPriority(id, updates);

        if (input.status === "done") {
          await db.logActivity({
            userId: ctx.user.id,
            actionType: "priority_completed",
            entityType: "weekly_priority",
            entityId: id,
            newValue: JSON.stringify(input),
            description: `${ctx.user.name} completed priority`,
            timestamp: Date.now(),
          });
        }

        return result;
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        return db.deleteWeeklyPriority(input.id);
      }),
  }),

  // ============================================================================
  // CELEBRATIONS
  // ============================================================================
  celebrations: router({
    getRecent: protectedProcedure
      .input(z.object({ limit: z.number().default(20) }))
      .query(async ({ input }) => {
        return db.getRecentCelebrations(input.limit);
      }),

    create: protectedProcedure
      .input(z.object({
        title: z.string().min(1),
        description: z.string().optional(),
        category: z.enum(["deal", "birthday", "milestone", "project", "personal"]),
        icon: z.string().default("🎉"),
        celebrationDate: z.date(),
        taggedUsers: z.array(z.number()).optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const celebration = await db.createCelebration({
          title: input.title,
          description: input.description,
          category: input.category,
          icon: input.icon,
          celebrationDate: input.celebrationDate,
          createdBy: ctx.user.id,
          taggedUsers: input.taggedUsers ? JSON.stringify(input.taggedUsers) : null,
        });

        await db.logActivity({
          userId: ctx.user.id,
          actionType: "celebration_added",
          entityType: "celebration",
          entityId: ctx.user.id,
          newValue: JSON.stringify(input),
          description: `${ctx.user.name} added celebration: ${input.title}`,
          timestamp: Date.now(),
        });

        return celebration;
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        return db.deleteCelebration(input.id);
      }),
  }),

  // ============================================================================
  // PIPELINES
  // ============================================================================
  pipelines: router({
    getCards: protectedProcedure
      .input(z.object({
        pipelineType: z.enum(["bd", "ventures", "studio", "clients", "finance", "admin"]),
      }))
      .query(async ({ input }) => {
        return db.getPipelineCards(input.pipelineType);
      }),

    createCard: protectedProcedure
      .input(z.object({
        stageId: z.number(),
        title: z.string().min(1),
        description: z.string().optional(),
        value: z.string().optional(),
        dueDate: z.date().optional(),
        ownerId: z.number().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const card = await db.createPipelineCard(input);

        await db.logActivity({
          userId: ctx.user.id,
          actionType: "card_created",
          entityType: "pipeline_card",
          entityId: card.id,
          newValue: JSON.stringify(input),
          description: `${ctx.user.name} created card: ${input.title}`,
          timestamp: Date.now(),
        });

        return card;
      }),

    updateCard: protectedProcedure
      .input(z.object({
        id: z.number(),
        title: z.string().optional(),
        description: z.string().optional(),
        value: z.string().optional(),
        dueDate: z.date().optional(),
        ownerId: z.number().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const { id, ...updates } = input;
        const result = await db.updatePipelineCard(id, updates);

        await db.logActivity({
          userId: ctx.user.id,
          actionType: "card_updated",
          entityType: "pipeline_card",
          entityId: id,
          newValue: JSON.stringify(updates),
          description: `${ctx.user.name} updated card`,
          timestamp: Date.now(),
        });

        return result;
      }),

    moveCard: protectedProcedure
      .input(z.object({
        cardId: z.number(),
        stageId: z.number(),
        position: z.number(),
      }))
      .mutation(async ({ ctx, input }) => {
        const result = await db.movePipelineCard(input.cardId, input.stageId, input.position);

        await db.logActivity({
          userId: ctx.user.id,
          actionType: "card_moved",
          entityType: "pipeline_card",
          entityId: input.cardId,
          newValue: JSON.stringify({ stageId: input.stageId, position: input.position }),
          description: `${ctx.user.name} moved card to new stage`,
          timestamp: Date.now(),
        });

        return result;
      }),

    deleteCard: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        return db.deletePipelineCard(input.id);
      }),
  }),

  // ============================================================================
  // ANNUAL GOALS
  // ============================================================================
  goals: router({
    getAnnual: protectedProcedure
      .input(z.object({ year: z.number() }))
      .query(async ({ input }) => {
        return db.getAnnualGoals(input.year);
      }),

    create: protectedProcedure
      .input(z.object({
        category: z.enum(["revenue", "ventures", "studio", "clients", "finance", "team", "admin"]),
        description: z.string().min(1),
        targetValue: z.string(),
        targetUnit: z.string(),
        year: z.number(),
        distributionStrategy: z.enum(["linear", "custom", "historical", "milestone"]).optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const goal = await db.createAnnualGoal({
          ...input,
          ownerId: ctx.user.id,
          distributionStrategy: input.distributionStrategy || "linear",
        });

        await db.logActivity({
          userId: ctx.user.id,
          actionType: "goal_created",
          entityType: "annual_goal",
          entityId: goal.id,
          newValue: JSON.stringify(input),
          description: `${ctx.user.name} created goal: ${input.description}`,
          timestamp: Date.now(),
        });

        return goal;
      }),

    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        description: z.string().optional(),
        targetValue: z.string().optional(),
        targetUnit: z.string().optional(),
        distributionStrategy: z.enum(["linear", "custom", "historical", "milestone"]).optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const { id, ...updates } = input;
        const result = await db.updateAnnualGoal(id, updates);

        await db.logActivity({
          userId: ctx.user.id,
          actionType: "goal_updated",
          entityType: "annual_goal",
          entityId: id,
          newValue: JSON.stringify(updates),
          description: `${ctx.user.name} updated goal`,
          timestamp: Date.now(),
        });

        return result;
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        return db.deleteAnnualGoal(input.id);
      }),

    generateCascade: protectedProcedure
      .input(z.object({
        goalId: z.number(),
        customWeights: z.array(z.object({
          month: z.number(),
          weight: z.number(),
          rationale: z.string().optional(),
        })).optional(),
      }))
      .mutation(async ({ input }) => {
        const goals = await db.getAnnualGoals(new Date().getFullYear());
        const goal = goals.find(g => g.id === input.goalId);
        
        if (!goal) {
          throw new TRPCError({ code: "NOT_FOUND", message: "Goal not found" });
        }

        const targetValue = parseFloat(goal.targetValue);
        const targets: any[] = [];

        if (input.customWeights && input.customWeights.length === 12) {
          for (const weight of input.customWeights) {
            targets.push({
              goalId: input.goalId,
              month: weight.month,
              year: goal.year,
              targetValue: (targetValue * weight.weight / 100).toFixed(2),
              weight: weight.weight.toFixed(2),
              rationale: weight.rationale,
              actualValue: "0",
            });
          }
        } else {
          const monthlyValue = (targetValue / 12).toFixed(2);
          for (let month = 1; month <= 12; month++) {
            targets.push({
              goalId: input.goalId,
              month,
              year: goal.year,
              targetValue: monthlyValue,
              weight: "8.33",
              rationale: "Linear distribution",
              actualValue: "0",
            });
          }
        }

        await db.bulkCreateMonthlyTargets(targets);
        return { success: true, targets };
      }),

    getMonthlyTargets: protectedProcedure
      .input(z.object({ goalId: z.number() }))
      .query(async ({ input }) => {
        return db.getMonthlyTargets(input.goalId);
      }),

    updateMonthlyActual: protectedProcedure
      .input(z.object({
        id: z.number(),
        actualValue: z.string(),
      }))
      .mutation(async ({ ctx, input }) => {
        const result = await db.updateMonthlyTarget(input.id, { actualValue: input.actualValue });

        await db.logActivity({
          userId: ctx.user.id,
          actionType: "target_updated",
          entityType: "monthly_target",
          entityId: input.id,
          newValue: JSON.stringify({ actualValue: input.actualValue }),
          description: `${ctx.user.name} updated monthly target actual value`,
          timestamp: Date.now(),
        });

        return result;
      }),
  }),

  // ============================================================================
  // ACTIVITY LOG
  // ============================================================================
  activity: router({
    getRecent: protectedProcedure
      .input(z.object({ limit: z.number().default(50) }))
      .query(async ({ input }) => {
        return db.getRecentActivity(input.limit);
      }),

    getByEntity: protectedProcedure
      .input(z.object({
        entityType: z.string(),
        entityId: z.number(),
      }))
      .query(async ({ input }) => {
        return db.getActivityByEntity(input.entityType, input.entityId);
      }),
  }),

  // ============================================================================
  // USERS
  // ============================================================================
  users: router({
    getAll: protectedProcedure.query(async () => {
      return db.getAllUsers();
    }),

    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        name: z.string().optional(),
        email: z.string().email().optional(),
        role: z.enum(["user", "admin"]).optional(),
        jobTitle: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user.role !== 'admin') {
          throw new TRPCError({
            code: 'FORBIDDEN',
            message: 'Only admins can update team members',
          });
        }
        const { id, ...data } = input;
        return db.updateUser(id, data);
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user.role !== 'admin') {
          throw new TRPCError({
            code: 'FORBIDDEN',
            message: 'Only admins can delete team members',
          });
        }
        if (input.id === ctx.user.id) {
          throw new TRPCError({
            code: 'BAD_REQUEST',
            message: 'Cannot delete your own account',
          });
        }
        return db.deleteUser(input.id);
      }),

    invite: protectedProcedure
      .input(z.object({
        name: z.string().min(1),
        email: z.string().email(),
        role: z.enum(["user", "admin"]).optional(),
        jobTitle: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user.role !== 'admin') {
          throw new TRPCError({
            code: 'FORBIDDEN',
            message: 'Only admins can invite team members',
          });
        }
        return db.createInvitedUser(input);
      }),
  }),

  // ============================================================================
  // CEO REFLECTIONS
  // ============================================================================
  ceoReflections: router({
    getCurrentWeek: protectedProcedure.query(async () => {
      const now = new Date();
      const weekNumber = getWeekNumber(now);
      const year = now.getFullYear();
      return db.getCeoReflection(weekNumber, year);
    }),

    save: protectedProcedure
      .input(z.object({
        content: z.string().min(1).max(2000),
      }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user.role !== 'admin') {
          throw new TRPCError({
            code: 'FORBIDDEN',
            message: 'Only the CEO can post reflections',
          });
        }

        const now = new Date();
        const weekNumber = getWeekNumber(now);
        const year = now.getFullYear();

        return db.upsertCeoReflection({
          content: input.content,
          weekNumber,
          year,
          createdBy: ctx.user.id,
        });
      }),
  }),
});

export type AppRouter = typeof appRouter;
