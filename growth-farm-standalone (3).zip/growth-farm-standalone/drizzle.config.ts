import type { Config } from "drizzle-kit";

export default {
  schema: "./server/schema.ts",
  out: "./drizzle",
  dialect: "sqlite",
  dbCredentials: {
    url: "./growth-farm.db",
  },
} satisfies Config;
