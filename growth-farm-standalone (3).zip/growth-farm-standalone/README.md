# Growth Farm Operating System

A comprehensive internal operations dashboard for Growth Farm, featuring team health tracking, pipeline management, goal setting, and more.

## Tech Stack

- **Frontend:** React 19 + TypeScript + Vite + Tailwind CSS + shadcn/ui
- **Backend:** Express + tRPC + Drizzle ORM
- **Database:** SQLite (for easy local development)

## Quick Start

### Prerequisites
- Node.js 18+ 
- pnpm (recommended) or npm

### Installation

```bash
# Install dependencies
pnpm install

# Initialize database and seed with demo data
pnpm db:push
pnpm seed

# Start development server
pnpm dev
```

The app will be available at:
- Frontend: http://localhost:5173
- Backend API: http://localhost:3000/api/trpc

### Demo Login

Use the quick login buttons on the login page:
- **CEO (Admin):** zweli@growthfarm.africa
- **Team Member:** albert@growthfarm.africa

Or create your own account via the login form.

## Project Structure

```
growth-farm-standalone/
├── client/                 # React frontend
│   ├── src/
│   │   ├── components/     # UI components (shadcn/ui)
│   │   ├── hooks/          # React hooks
│   │   ├── lib/            # Utilities and trpc client
│   │   ├── pages/          # Page components
│   │   └── contexts/       # React contexts
│   └── index.html
├── server/                 # Express + tRPC backend
│   ├── schema.ts           # Drizzle database schema
│   ├── db.ts               # Database operations
│   ├── routers.ts          # tRPC API routes
│   ├── context.ts          # tRPC context
│   ├── index.ts            # Server entry point
│   └── seed.ts             # Database seeding script
├── shared/                 # Shared types and constants
└── drizzle/                # Database migrations
```

## Features

### Implemented ✅
- **Home Page:** Team health pulse, individual check-ins, weekly priorities, celebrations feed, CEO reflections
- **Dashboard:** Revenue tracking, BD pipeline overview, venture/studio/client metrics, alerts
- **Settings:** Team management, strategic objectives, company info, business units
- **Authentication:** Simple cookie-based auth for development

### In Progress 🔨
- **Engine:** Operations hub with 6-tile navigation (BD, Ventures, Studio, Delivery, Finance, Admin)
- **Monthly:** KPI cascade with target vs actual tracking
- **Weekly:** Excel-like activity tracker

### Planned 📋
- Kanban boards with drag-and-drop
- Trend analysis and reporting
- Mobile PWA optimization

## Brand Identity

The UI follows the Growth Farm brand guidelines:
- **Colors:** Earth browns (#5D4037, #3E2723), dusty pink (#D4A5A5), cream (#FAF8F5)
- **Typography:** Playfair Display for headings, Inter for body text
- **Theme:** Professional with a hint of playfulness (the pink balloon!)

## Development Commands

```bash
# Start dev server (frontend + backend)
pnpm dev

# Run type checking
pnpm check

# Format code
pnpm format

# Database commands
pnpm db:push     # Push schema changes
pnpm db:studio   # Open Drizzle Studio
pnpm seed        # Seed demo data
```

## Deployment

For production:

```bash
pnpm build
pnpm start
```

The build outputs to `dist/` with the client served statically by Express.

## License

MIT
