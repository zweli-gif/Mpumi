import { Redirect } from "wouter";

// Trends functionality is now part of Dashboard
export default function Trends() {
  return <Redirect to="/dashboard" />;
}
