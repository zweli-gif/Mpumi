import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { trpc } from "@/lib/trpc";
import { PageHeader } from "@/components/PageHeader";
import { BottomNav } from "@/components/BottomNav";
import { 
  Users, 
  Building2, 
  Compass, 
  Plus, 
  Edit2, 
  Trash2,
  Loader2,
  Shield,
  Rocket,
  Target
} from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

// Goal type for the table
type Goal = {
  id: string;
  name: string;
  target: string;
  unit: string;
  owner: string;
};

// Strategic Objectives with icons and goals
const INITIAL_OBJECTIVES = [
  { 
    id: "community-growth", 
    name: "Community Growth", 
    icon: Users, 
    color: "text-green-600 bg-green-100", 
    description: "Building and nurturing our community of entrepreneurs and innovators",
    goals: [] as Goal[]
  },
  { 
    id: "impact-delivery", 
    name: "Impact Delivery", 
    icon: Target, 
    color: "text-blue-600 bg-blue-100", 
    description: "Delivering measurable impact through our ventures and initiatives",
    goals: [] as Goal[]
  },
  { 
    id: "new-frontiers", 
    name: "New Frontiers", 
    icon: Rocket, 
    color: "text-purple-600 bg-purple-100", 
    description: "Exploring new opportunities and expanding into new markets",
    goals: [] as Goal[]
  },
  { 
    id: "stewardship", 
    name: "Stewardship", 
    icon: Shield, 
    color: "text-amber-600 bg-amber-100", 
    description: "Responsible management of resources and relationships",
    goals: [] as Goal[]
  },
  { 
    id: "purpose-platform", 
    name: "Purpose & Platform", 
    icon: Compass, 
    color: "text-rose-600 bg-rose-100", 
    description: "Building our brand and amplifying our mission",
    goals: [] as Goal[]
  },
];

// Initial departments
const INITIAL_DEPARTMENTS = [
  { id: "venture-studio", name: "Venture Studio", description: "Ideating and incubating new ventures" },
  { id: "design-studio", name: "Design Studio", description: "User acquisition and retention services" },
  { id: "investment-arm", name: "Investment Arm", description: "Strategic investments in portfolio companies" },
  { id: "advisory", name: "Advisory", description: "Consulting and advisory services" },
];

export default function Settings() {
  const { user, loading } = useAuth();
  const [activeTab, setActiveTab] = useState("team");
  
  // Strategic Objectives state
  const [objectives, setObjectives] = useState(INITIAL_OBJECTIVES);
  const [editingObjective, setEditingObjective] = useState<typeof INITIAL_OBJECTIVES[0] | null>(null);
  const [goalDialogOpen, setGoalDialogOpen] = useState(false);
  const [newObjectiveDialogOpen, setNewObjectiveDialogOpen] = useState(false);
  const [newObjectiveName, setNewObjectiveName] = useState("");
  const [newObjectiveDescription, setNewObjectiveDescription] = useState("");
  
  // Goals editing state
  const [editingGoals, setEditingGoals] = useState<Goal[]>([
    { id: "1", name: "", target: "", unit: "%", owner: "" },
    { id: "2", name: "", target: "", unit: "%", owner: "" },
    { id: "3", name: "", target: "", unit: "%", owner: "" },
  ]);
  
  // Departments state
  const [departments, setDepartments] = useState(INITIAL_DEPARTMENTS);
  const [editingDepartment, setEditingDepartment] = useState<typeof INITIAL_DEPARTMENTS[0] | null>(null);
  const [departmentDialogOpen, setDepartmentDialogOpen] = useState(false);
  const [newDeptName, setNewDeptName] = useState("");
  const [newDeptDescription, setNewDeptDescription] = useState("");

  // Queries
  const { data: allUsers, isLoading: usersLoading } = trpc.users.getAll.useQuery();

  // Open goal editing dialog
  const openGoalDialog = (objective: typeof INITIAL_OBJECTIVES[0]) => {
    setEditingObjective(objective);
    // Pre-fill with existing goals or empty rows
    const existingGoals = objective.goals.length > 0 
      ? [...objective.goals]
      : [
          { id: "1", name: "", target: "", unit: "%", owner: "" },
          { id: "2", name: "", target: "", unit: "%", owner: "" },
          { id: "3", name: "", target: "", unit: "%", owner: "" },
        ];
    setEditingGoals(existingGoals);
    setGoalDialogOpen(true);
  };

  // Update goal in editing state
  const updateGoal = (index: number, field: keyof Goal, value: string) => {
    const newGoals = [...editingGoals];
    newGoals[index] = { ...newGoals[index], [field]: value };
    setEditingGoals(newGoals);
  };

  // Add more goal rows
  const addMoreGoals = () => {
    const newId = String(editingGoals.length + 1);
    setEditingGoals([...editingGoals, { id: newId, name: "", target: "", unit: "%", owner: "" }]);
  };

  // Save goals to objective
  const saveGoals = () => {
    if (!editingObjective) return;
    
    // Filter out empty goals
    const validGoals = editingGoals.filter(g => g.name.trim() !== "");
    
    setObjectives(prev => prev.map(obj => 
      obj.id === editingObjective.id 
        ? { ...obj, goals: validGoals }
        : obj
    ));
    
    setGoalDialogOpen(false);
    toast.success(`Goals saved for ${editingObjective.name}`);
  };

  // Add new strategic objective
  const addNewObjective = () => {
    if (!newObjectiveName.trim()) {
      toast.error("Please enter an objective name");
      return;
    }
    
    const newObj = {
      id: `custom-${Date.now()}`,
      name: newObjectiveName,
      icon: Target,
      color: "text-gray-600 bg-gray-100",
      description: newObjectiveDescription || "Custom strategic objective",
      goals: [] as Goal[]
    };
    
    setObjectives([...objectives, newObj]);
    setNewObjectiveName("");
    setNewObjectiveDescription("");
    setNewObjectiveDialogOpen(false);
    toast.success(`Added "${newObjectiveName}" objective`);
  };

  // Open department editing dialog
  const openDepartmentDialog = (dept?: typeof INITIAL_DEPARTMENTS[0]) => {
    if (dept) {
      setEditingDepartment(dept);
      setNewDeptName(dept.name);
      setNewDeptDescription(dept.description);
    } else {
      setEditingDepartment(null);
      setNewDeptName("");
      setNewDeptDescription("");
    }
    setDepartmentDialogOpen(true);
  };

  // Save department
  const saveDepartment = () => {
    if (!newDeptName.trim()) {
      toast.error("Please enter a department name");
      return;
    }
    
    if (editingDepartment) {
      // Update existing
      setDepartments(prev => prev.map(d => 
        d.id === editingDepartment.id 
          ? { ...d, name: newDeptName, description: newDeptDescription }
          : d
      ));
      toast.success(`Updated "${newDeptName}"`);
    } else {
      // Add new
      const newDept = {
        id: `dept-${Date.now()}`,
        name: newDeptName,
        description: newDeptDescription
      };
      setDepartments([...departments, newDept]);
      toast.success(`Added "${newDeptName}"`);
    }
    
    setDepartmentDialogOpen(false);
  };

  // Delete department
  const deleteDepartment = (id: string) => {
    setDepartments(prev => prev.filter(d => d.id !== id));
    toast.success("Department removed");
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  // Only admin can access settings
  if (user?.role !== 'admin') {
    return (
      <div className="min-h-screen bg-background pb-20">
        <PageHeader title="SETTINGS" subtitle="Team & Company Configuration" />
        <main className="container py-8">
          <Card>
            <CardContent className="py-12 text-center">
              <Shield className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
              <h2 className="text-xl font-semibold mb-2">Admin Access Required</h2>
              <p className="text-muted-foreground">Only administrators can access settings.</p>
            </CardContent>
          </Card>
        </main>
        <BottomNav />
      </div>
    );
  }


  return (
    <div className="min-h-screen bg-background pb-20">
      <PageHeader title="SETTINGS" subtitle="Team & Company Configuration" />

      <main className="container py-6">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="team" className="flex items-center gap-2">
              <Users className="h-4 w-4" />
              <span className="hidden sm:inline">Team</span>
            </TabsTrigger>
            <TabsTrigger value="objectives" className="flex items-center gap-2">
              <Compass className="h-4 w-4" />
              <span className="hidden sm:inline">Objectives</span>
            </TabsTrigger>
            <TabsTrigger value="company" className="flex items-center gap-2">
              <Building2 className="h-4 w-4" />
              <span className="hidden sm:inline">Company</span>
            </TabsTrigger>
          </TabsList>

          {/* Team Members Tab */}
          <TabsContent value="team" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Team Members</CardTitle>
                    <CardDescription>Manage your Growth Farm team</CardDescription>
                  </div>
                  <Button size="sm" onClick={() => toast.info("Invite team members via the Manus platform")}>
                    <Plus className="h-4 w-4 mr-1" />
                    Invite
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {usersLoading ? (
                  <div className="flex justify-center py-8">
                    <Loader2 className="h-6 w-6 animate-spin" />
                  </div>
                ) : (
                  <div className="space-y-4">
                    {allUsers?.map((member: any) => (
                      <div key={member.id} className="flex items-center justify-between p-4 border rounded-lg">
                        <div className="flex items-center gap-4">
                          <Avatar className="h-12 w-12">
                            <AvatarImage src={member.avatarUrl || undefined} />
                            <AvatarFallback className="bg-primary/10 text-primary font-medium">
                              {member.name?.split(' ').map((n: string) => n[0]).join('').slice(0, 2) || '??'}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="font-medium">{member.name || 'Unnamed'}</p>
                            <p className="text-sm text-muted-foreground">{member.email || 'No email'}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge variant={member.role === 'admin' ? 'default' : 'secondary'}>
                            {member.role === 'admin' ? 'Admin' : 'Member'}
                          </Badge>
                          <Badge variant="outline" className={
                            (member.currentHealthScore || 0) >= 80 ? 'bg-green-100 text-green-800' :
                            (member.currentHealthScore || 0) >= 60 ? 'bg-yellow-100 text-yellow-800' :
                            'bg-red-100 text-red-800'
                          }>
                            {member.currentHealthScore || 0}%
                          </Badge>
                        </div>
                      </div>
                    ))}
                    {(!allUsers || allUsers.length === 0) && (
                      <p className="text-center text-muted-foreground py-8">No team members found</p>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Strategic Objectives Tab */}
          <TabsContent value="objectives" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Strategic Objectives</CardTitle>
                    <CardDescription>The pillars guiding Growth Farm's mission</CardDescription>
                  </div>
                  <Dialog open={newObjectiveDialogOpen} onOpenChange={setNewObjectiveDialogOpen}>
                    <DialogTrigger asChild>
                      <Button size="sm" variant="outline">
                        <Plus className="h-4 w-4 mr-1" />
                        Add
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Add Strategic Objective</DialogTitle>
                        <DialogDescription>Create a new strategic pillar for Growth Farm</DialogDescription>
                      </DialogHeader>
                      <div className="space-y-4 py-4">
                        <div className="space-y-2">
                          <Label htmlFor="obj-name">Objective Name</Label>
                          <Input 
                            id="obj-name" 
                            value={newObjectiveName}
                            onChange={(e) => setNewObjectiveName(e.target.value)}
                            placeholder="e.g., Market Expansion"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="obj-desc">Description</Label>
                          <Input 
                            id="obj-desc" 
                            value={newObjectiveDescription}
                            onChange={(e) => setNewObjectiveDescription(e.target.value)}
                            placeholder="Brief description of this objective"
                          />
                        </div>
                      </div>
                      <DialogFooter>
                        <Button onClick={addNewObjective}>Add Objective</Button>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {objectives.map((objective) => {
                    const Icon = objective.icon;
                    return (
                      <div key={objective.id} className="flex items-start gap-4 p-4 border rounded-lg">
                        <div className={`p-2 rounded-lg ${objective.color}`}>
                          <Icon className="h-5 w-5" />
                        </div>
                        <div className="flex-1">
                          <h3 className="font-medium">{objective.name}</h3>
                          <p className="text-sm text-muted-foreground">{objective.description}</p>
                          {objective.goals.length > 0 && (
                            <p className="text-xs text-muted-foreground mt-1">
                              {objective.goals.length} goal{objective.goals.length > 1 ? 's' : ''} defined
                            </p>
                          )}
                        </div>
                        <Button variant="ghost" size="sm" onClick={() => openGoalDialog(objective)}>
                          <Edit2 className="h-4 w-4" />
                        </Button>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>

            {/* Goal Editing Dialog */}
            <Dialog open={goalDialogOpen} onOpenChange={setGoalDialogOpen}>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>Edit Goals - {editingObjective?.name}</DialogTitle>
                  <DialogDescription>Define annual goals for this strategic objective</DialogDescription>
                </DialogHeader>
                <div className="py-4">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-[200px]">Goal Name</TableHead>
                        <TableHead className="w-[100px]">Annual Target</TableHead>
                        <TableHead className="w-[80px]">Unit</TableHead>
                        <TableHead>EXCO Owner</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {editingGoals.map((goal, index) => (
                        <TableRow key={goal.id}>
                          <TableCell>
                            <Input 
                              value={goal.name}
                              onChange={(e) => updateGoal(index, 'name', e.target.value)}
                              placeholder="Goal name"
                              className="h-8"
                            />
                          </TableCell>
                          <TableCell>
                            <Input 
                              value={goal.target}
                              onChange={(e) => updateGoal(index, 'target', e.target.value)}
                              placeholder="100"
                              className="h-8"
                            />
                          </TableCell>
                          <TableCell>
                            <Select value={goal.unit} onValueChange={(v) => updateGoal(index, 'unit', v)}>
                              <SelectTrigger className="h-8">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="%">%</SelectItem>
                                <SelectItem value="$">$</SelectItem>
                                <SelectItem value="R">R</SelectItem>
                                <SelectItem value="#">#</SelectItem>
                              </SelectContent>
                            </Select>
                          </TableCell>
                          <TableCell>
                            <Select value={goal.owner} onValueChange={(v) => updateGoal(index, 'owner', v)}>
                              <SelectTrigger className="h-8">
                                <SelectValue placeholder="Select owner" />
                              </SelectTrigger>
                              <SelectContent>
                                {allUsers?.map((u: any) => (
                                  <SelectItem key={u.id} value={u.name || u.email}>
                                    {u.name || u.email}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                  <Button 
                    variant="outline" 
                    className="w-full mt-4"
                    onClick={addMoreGoals}
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Add More
                  </Button>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setGoalDialogOpen(false)}>Cancel</Button>
                  <Button onClick={saveGoals}>Save Goals</Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </TabsContent>

          {/* Company Info Tab */}
          <TabsContent value="company" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Company Information</CardTitle>
                <CardDescription>Growth Farm branding and details</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="company-name">Company Name</Label>
                    <Input id="company-name" defaultValue="Growth Farm" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="tagline">Tagline</Label>
                    <Input id="tagline" defaultValue="Africa's Premier Venture Studio" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="mission">Mission Statement</Label>
                    <Input id="mission" defaultValue="Building the largest African venture capital firm that ideates and incubates its own ideas" />
                  </div>
                </div>

                <Separator />

                <div>
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="font-medium">Business Units</h3>
                    <Button size="sm" variant="outline" onClick={() => openDepartmentDialog()}>
                      <Plus className="h-4 w-4 mr-1" />
                      Add
                    </Button>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {departments.map((dept) => (
                      <div key={dept.id} className="p-4 border rounded-lg group relative">
                        <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity flex gap-1">
                          <Button variant="ghost" size="sm" className="h-7 w-7 p-0" onClick={() => openDepartmentDialog(dept)}>
                            <Edit2 className="h-3 w-3" />
                          </Button>
                          <Button variant="ghost" size="sm" className="h-7 w-7 p-0 text-destructive" onClick={() => deleteDepartment(dept.id)}>
                            <Trash2 className="h-3 w-3" />
                          </Button>
                        </div>
                        <h4 className="font-medium">{dept.name}</h4>
                        <p className="text-sm text-muted-foreground">{dept.description}</p>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="flex justify-end">
                  <Button onClick={() => toast.success("Company settings saved!")}>
                    Save Changes
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Department Edit Dialog */}
            <Dialog open={departmentDialogOpen} onOpenChange={setDepartmentDialogOpen}>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>{editingDepartment ? 'Edit' : 'Add'} Business Unit</DialogTitle>
                  <DialogDescription>
                    {editingDepartment ? 'Update the department details' : 'Add a new business unit to Growth Farm'}
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <Label htmlFor="dept-name">Department Name</Label>
                    <Input 
                      id="dept-name" 
                      value={newDeptName}
                      onChange={(e) => setNewDeptName(e.target.value)}
                      placeholder="e.g., Research & Development"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="dept-desc">Description</Label>
                    <Input 
                      id="dept-desc" 
                      value={newDeptDescription}
                      onChange={(e) => setNewDeptDescription(e.target.value)}
                      placeholder="Brief description of this unit"
                    />
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setDepartmentDialogOpen(false)}>Cancel</Button>
                  <Button onClick={saveDepartment}>
                    {editingDepartment ? 'Save Changes' : 'Add Department'}
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </TabsContent>
        </Tabs>
      </main>

      <BottomNav />
    </div>
  );
}
