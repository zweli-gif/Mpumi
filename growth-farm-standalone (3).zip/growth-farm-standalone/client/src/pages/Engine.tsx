import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { PageHeader } from "@/components/PageHeader";
import { BottomNav } from "@/components/BottomNav";
import { trpc } from "@/lib/trpc";
import {
  TrendingUp, Rocket, Palette, Users, DollarSign, Settings,
  Loader2, Plus, GripVertical, MoreHorizontal, ArrowRight,
  Building2, Calendar, Target, Clock
} from "lucide-react";
import { toast } from "sonner";

// Engine tiles configuration using new nomenclature
const ENGINE_TILES = [
  { id: "bd", name: "Community Growth", subtitle: "BD Pipeline", icon: TrendingUp, color: "bg-green-100 text-green-700", count: 7, value: "R4.9M" },
  { id: "ventures", name: "New Frontiers", subtitle: "Ventures", icon: Rocket, color: "bg-purple-100 text-purple-700", count: 3, value: "Active" },
  { id: "studio", name: "Impact Delivery", subtitle: "Studio", icon: Palette, color: "bg-blue-100 text-blue-700", count: 2, value: "R2.1M" },
  { id: "delivery", name: "Client Success", subtitle: "Delivery", icon: Users, color: "bg-cyan-100 text-cyan-700", count: 4, value: "On Track" },
  { id: "finance", name: "Stewardship", subtitle: "Finance", icon: DollarSign, color: "bg-amber-100 text-amber-700", count: 5, value: "R250K" },
  { id: "admin", name: "Purpose & Platform", subtitle: "Admin", icon: Settings, color: "bg-rose-100 text-rose-700", count: 2, value: "Pending" },
];

// BD Pipeline stages
const BD_STAGES = [
  { id: "lead", name: "Lead", color: "bg-slate-100" },
  { id: "discovery", name: "Discovery", color: "bg-blue-100" },
  { id: "proposal", name: "Proposal", color: "bg-indigo-100" },
  { id: "negotiation", name: "Negotiation", color: "bg-purple-100" },
  { id: "contracting", name: "Contracting", color: "bg-pink-100" },
  { id: "won", name: "Won", color: "bg-green-100" },
  { id: "lost", name: "Lost", color: "bg-red-100" },
];

// Venture stages
const VENTURE_STAGES = ["Ideation", "Validation", "MVP", "Growth", "Scale"];

// Mock BD Pipeline data
const MOCK_BD_CARDS = [
  { id: 1, title: "MTN Digital Services", value: 1200000, stage: "won", contact: "John K.", nextAction: "Kickoff meeting", daysInStage: 5, owner: "Zweli" },
  { id: 2, title: "Standard Bank Innovation", value: 800000, stage: "proposal", contact: "Sarah M.", nextAction: "Send revised proposal", daysInStage: 12, owner: "Albert" },
  { id: 3, title: "Vodacom Enterprise", value: 1500000, stage: "discovery", contact: "Mike R.", nextAction: "Demo call scheduled", daysInStage: 3, owner: "Zweli" },
  { id: 4, title: "FNB Mobile", value: 600000, stage: "lead", contact: "Lisa T.", nextAction: "Initial outreach", daysInStage: 1, owner: "Brian" },
  { id: 5, title: "Absa Ventures", value: 400000, stage: "negotiation", contact: "Peter W.", nextAction: "Contract review", daysInStage: 8, owner: "Zweli" },
  { id: 6, title: "Discovery Health", value: 350000, stage: "contracting", contact: "Emma S.", nextAction: "Sign agreement", daysInStage: 2, owner: "Albert" },
  { id: 7, title: "Capitec Digital", value: 500000, stage: "lead", contact: "David L.", nextAction: "Qualify opportunity", daysInStage: 4, owner: "Brian" },
];

// Mock Ventures data
const MOCK_VENTURES = [
  { id: 1, name: "Mntase! Communities", stage: "MVP", burnRate: 45000, targetBurn: 50000, daysToRevenue: 120, runway: 8, keyMetric: "50K users" },
  { id: 2, name: "briansfomo", stage: "Validation", burnRate: 15000, targetBurn: 20000, daysToRevenue: 180, runway: 12, keyMetric: "3 events" },
  { id: 3, name: "Mntase Living", stage: "Ideation", burnRate: 5000, targetBurn: 10000, daysToRevenue: 365, runway: 24, keyMetric: "Research" },
];

// Mock Studio projects
const MOCK_STUDIO = [
  { id: 1, name: "IBM Accelerator", client: "IBM", billedAmount: 1200000, targetAmount: 1500000, status: "on-track", endDate: "2026-06-30", progress: 65 },
  { id: 2, name: "FNB Mobile Redesign", client: "FNB", billedAmount: 450000, targetAmount: 600000, status: "at-risk", endDate: "2026-03-15", progress: 40 },
];

// Mock Delivery data
const MOCK_DELIVERY = [
  { id: 1, client: "IBM", project: "Accelerator Sprint 4", health: "green", nextMilestone: "Prototype Review", dueDate: "2026-02-15" },
  { id: 2, client: "FNB", project: "Mobile App", health: "yellow", nextMilestone: "User Testing", dueDate: "2026-02-10" },
  { id: 3, client: "MTN", project: "Digital Services", health: "green", nextMilestone: "Phase 1 Launch", dueDate: "2026-02-28" },
  { id: 4, client: "Standard Bank", project: "Innovation Portal", health: "green", nextMilestone: "Design Sign-off", dueDate: "2026-02-20" },
];

// Mock Finance data
const MOCK_FINANCE = [
  { id: 1, type: "Invoice", description: "IBM - January", amount: 400000, status: "pending", dueDate: "2026-02-15" },
  { id: 2, type: "Expense", description: "Cloud Services", amount: -15000, status: "approved", dueDate: "2026-02-01" },
  { id: 3, type: "Invoice", description: "FNB - Milestone 2", amount: 150000, status: "sent", dueDate: "2026-02-10" },
  { id: 4, type: "Tax", description: "VAT Payment", amount: -85000, status: "pending", dueDate: "2026-02-25" },
  { id: 5, type: "Payroll", description: "February Salaries", amount: -180000, status: "scheduled", dueDate: "2026-02-28" },
];

export default function Engine() {
  const { user, loading } = useAuth();
  const [activeSection, setActiveSection] = useState<string | null>(null);
  const [bdCards, setBdCards] = useState(MOCK_BD_CARDS);
  const [addDealOpen, setAddDealOpen] = useState(false);
  const [newDeal, setNewDeal] = useState({ title: "", value: "", contact: "", stage: "lead" });

  // Format currency
  const formatCurrency = (amount: number): string => {
    if (Math.abs(amount) >= 1000000) return `R${(amount / 1000000).toFixed(1)}M`;
    if (Math.abs(amount) >= 1000) return `R${(amount / 1000).toFixed(0)}K`;
    return `R${amount}`;
  };

  // Calculate stage totals for BD
  const getStageTotal = (stageId: string) => {
    const stageCards = bdCards.filter((c) => c.stage === stageId);
    return {
      count: stageCards.length,
      value: stageCards.reduce((sum, c) => sum + c.value, 0),
    };
  };

  // Move card to new stage
  const moveCard = (cardId: number, newStage: string) => {
    setBdCards((prev) =>
      prev.map((c) => (c.id === cardId ? { ...c, stage: newStage, daysInStage: 0 } : c))
    );
    toast.success("Deal moved successfully");
  };

  // Add new deal
  const handleAddDeal = () => {
    if (!newDeal.title || !newDeal.value) {
      toast.error("Please fill in required fields");
      return;
    }
    const deal = {
      id: Date.now(),
      title: newDeal.title,
      value: parseFloat(newDeal.value),
      stage: newDeal.stage,
      contact: newDeal.contact,
      nextAction: "Initial outreach",
      daysInStage: 0,
      owner: user?.name || "Unassigned",
    };
    setBdCards([...bdCards, deal]);
    setNewDeal({ title: "", value: "", contact: "", stage: "lead" });
    setAddDealOpen(false);
    toast.success("Deal added to pipeline");
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-20 md:pb-0">
      <PageHeader title="ENGINE" subtitle="Operations Hub" />

      <main className="container py-4 space-y-4">
        {/* 6-Tile Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          {ENGINE_TILES.map((tile) => {
            const Icon = tile.icon;
            return (
              <Card
                key={tile.id}
                className={`cursor-pointer hover:shadow-md transition-shadow ${activeSection === tile.id ? "ring-2 ring-primary" : ""}`}
                onClick={() => setActiveSection(tile.id)}
              >
                <CardContent className="p-4">
                  <div className={`w-10 h-10 rounded-lg ${tile.color} flex items-center justify-center mb-3`}>
                    <Icon className="h-5 w-5" />
                  </div>
                  <h3 className="font-semibold text-sm">{tile.name}</h3>
                  <p className="text-xs text-muted-foreground">{tile.subtitle}</p>
                  <div className="flex items-center justify-between mt-2">
                    <Badge variant="secondary" className="text-xs">{tile.count} items</Badge>
                    <span className="text-xs font-medium">{tile.value}</span>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Section Detail Sheet */}
        <Sheet open={!!activeSection} onOpenChange={(open) => !open && setActiveSection(null)}>
          <SheetContent side="bottom" className="h-[85vh] overflow-y-auto">
            <SheetHeader>
              <SheetTitle className="flex items-center gap-2">
                {activeSection && ENGINE_TILES.find((t) => t.id === activeSection)?.name}
              </SheetTitle>
              <SheetDescription>
                {activeSection === "bd" && "Business development pipeline"}
                {activeSection === "ventures" && "Active venture portfolio"}
                {activeSection === "studio" && "Studio project delivery"}
                {activeSection === "delivery" && "Client delivery health"}
                {activeSection === "finance" && "Financial overview"}
                {activeSection === "admin" && "Administrative tasks"}
              </SheetDescription>
            </SheetHeader>

            <div className="mt-4">
              {/* BD Pipeline - Kanban View */}
              {activeSection === "bd" && (
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <h3 className="font-medium">Pipeline Overview</h3>
                    <Button size="sm" onClick={() => setAddDealOpen(true)}>
                      <Plus className="h-4 w-4 mr-1" />
                      Add Deal
                    </Button>
                  </div>
                  
                  {/* Stage Summary */}
                  <div className="grid grid-cols-7 gap-2 text-center">
                    {BD_STAGES.map((stage) => {
                      const { count, value } = getStageTotal(stage.id);
                      return (
                        <div key={stage.id} className={`p-2 rounded ${stage.color}`}>
                          <p className="text-xs font-medium truncate">{stage.name}</p>
                          <p className="text-lg font-bold">{count}</p>
                          <p className="text-xs text-muted-foreground">{formatCurrency(value)}</p>
                        </div>
                      );
                    })}
                  </div>

                  {/* Deal Cards */}
                  <div className="space-y-2">
                    {bdCards.map((card) => (
                      <Card key={card.id} className="p-3">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center gap-2">
                              <h4 className="font-medium">{card.title}</h4>
                              <Badge variant="outline" className="text-xs">{BD_STAGES.find((s) => s.id === card.stage)?.name}</Badge>
                            </div>
                            <p className="text-lg font-bold mt-1">{formatCurrency(card.value)}</p>
                            <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground">
                              <span>{card.contact}</span>
                              <span>{card.daysInStage}d in stage</span>
                              <span>{card.owner}</span>
                            </div>
                            <p className="text-xs mt-1"><span className="font-medium">Next:</span> {card.nextAction}</p>
                          </div>
                          <Select value={card.stage} onValueChange={(v) => moveCard(card.id, v)}>
                            <SelectTrigger className="w-[120px] h-8">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              {BD_STAGES.map((s) => (
                                <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </Card>
                    ))}
                  </div>
                </div>
              )}

              {/* Ventures */}
              {activeSection === "ventures" && (
                <div className="space-y-4">
                  <h3 className="font-medium">Venture Portfolio</h3>
                  {MOCK_VENTURES.map((venture) => (
                    <Card key={venture.id} className="p-4">
                      <div className="flex items-start justify-between">
                        <div>
                          <h4 className="font-semibold">{venture.name}</h4>
                          <Badge variant="outline" className="mt-1">{venture.stage}</Badge>
                        </div>
                        <div className="text-right">
                          <p className="text-sm font-medium">{venture.keyMetric}</p>
                          <p className="text-xs text-muted-foreground">{venture.runway}mo runway</p>
                        </div>
                      </div>
                      <div className="grid grid-cols-3 gap-4 mt-4 text-center">
                        <div>
                          <p className="text-xs text-muted-foreground">Burn Rate</p>
                          <p className="font-medium">{formatCurrency(venture.burnRate)}/mo</p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">Target Burn</p>
                          <p className="font-medium">{formatCurrency(venture.targetBurn)}/mo</p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">Days to Revenue</p>
                          <p className="font-medium">{venture.daysToRevenue}d</p>
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>
              )}

              {/* Studio */}
              {activeSection === "studio" && (
                <div className="space-y-4">
                  <h3 className="font-medium">Studio Projects</h3>
                  {MOCK_STUDIO.map((project) => (
                    <Card key={project.id} className="p-4">
                      <div className="flex items-start justify-between">
                        <div>
                          <h4 className="font-semibold">{project.name}</h4>
                          <p className="text-sm text-muted-foreground">{project.client}</p>
                        </div>
                        <Badge variant={project.status === "on-track" ? "default" : "destructive"}>
                          {project.status === "on-track" ? "🟢 On Track" : "🟡 At Risk"}
                        </Badge>
                      </div>
                      <div className="mt-4">
                        <div className="flex justify-between text-sm mb-1">
                          <span>Billing Progress</span>
                          <span>{Math.round((project.billedAmount / project.targetAmount) * 100)}%</span>
                        </div>
                        <div className="h-2 bg-muted rounded-full overflow-hidden">
                          <div
                            className="h-full bg-primary transition-all"
                            style={{ width: `${(project.billedAmount / project.targetAmount) * 100}%` }}
                          />
                        </div>
                        <div className="flex justify-between text-xs text-muted-foreground mt-1">
                          <span>{formatCurrency(project.billedAmount)} billed</span>
                          <span>{formatCurrency(project.targetAmount)} target</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-4 mt-3 text-xs">
                        <span className="flex items-center gap-1"><Calendar className="h-3 w-3" /> End: {project.endDate}</span>
                        <span className="flex items-center gap-1"><Target className="h-3 w-3" /> {project.progress}% complete</span>
                      </div>
                    </Card>
                  ))}
                </div>
              )}

              {/* Delivery */}
              {activeSection === "delivery" && (
                <div className="space-y-4">
                  <h3 className="font-medium">Client Delivery Status</h3>
                  {MOCK_DELIVERY.map((item) => (
                    <Card key={item.id} className="p-4">
                      <div className="flex items-start justify-between">
                        <div>
                          <h4 className="font-semibold">{item.client}</h4>
                          <p className="text-sm text-muted-foreground">{item.project}</p>
                        </div>
                        <span className={`text-lg ${item.health === "green" ? "text-green-500" : "text-yellow-500"}`}>
                          {item.health === "green" ? "🟢" : "🟡"}
                        </span>
                      </div>
                      <div className="flex items-center gap-4 mt-3 text-xs text-muted-foreground">
                        <span><strong>Next:</strong> {item.nextMilestone}</span>
                        <span><strong>Due:</strong> {item.dueDate}</span>
                      </div>
                    </Card>
                  ))}
                </div>
              )}

              {/* Finance */}
              {activeSection === "finance" && (
                <div className="space-y-4">
                  <h3 className="font-medium">Financial Items</h3>
                  {MOCK_FINANCE.map((item) => (
                    <Card key={item.id} className="p-4">
                      <div className="flex items-start justify-between">
                        <div>
                          <Badge variant="outline" className="mb-1">{item.type}</Badge>
                          <h4 className="font-medium">{item.description}</h4>
                        </div>
                        <div className="text-right">
                          <p className={`font-bold ${item.amount >= 0 ? "text-green-600" : "text-red-600"}`}>
                            {item.amount >= 0 ? "+" : ""}{formatCurrency(item.amount)}
                          </p>
                          <Badge variant="secondary" className="text-xs">{item.status}</Badge>
                        </div>
                      </div>
                      <p className="text-xs text-muted-foreground mt-2">Due: {item.dueDate}</p>
                    </Card>
                  ))}
                </div>
              )}

              {/* Admin */}
              {activeSection === "admin" && (
                <div className="space-y-4">
                  <h3 className="font-medium">Administrative Tasks</h3>
                  <Card className="p-4">
                    <p className="text-muted-foreground text-center py-8">
                      Admin section for HR, IT, and operational tasks coming soon.
                    </p>
                  </Card>
                </div>
              )}
            </div>
          </SheetContent>
        </Sheet>

        {/* Add Deal Dialog */}
        <Dialog open={addDealOpen} onOpenChange={setAddDealOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add New Deal</DialogTitle>
              <DialogDescription>Add a deal to the BD pipeline</DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label>Company Name *</Label>
                <Input
                  value={newDeal.title}
                  onChange={(e) => setNewDeal({ ...newDeal, title: e.target.value })}
                  placeholder="e.g., Vodacom Enterprise"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Deal Value (R) *</Label>
                  <Input
                    type="number"
                    value={newDeal.value}
                    onChange={(e) => setNewDeal({ ...newDeal, value: e.target.value })}
                    placeholder="500000"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Stage</Label>
                  <Select value={newDeal.stage} onValueChange={(v) => setNewDeal({ ...newDeal, stage: v })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {BD_STAGES.slice(0, 5).map((s) => (
                        <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-2">
                <Label>Contact Person</Label>
                <Input
                  value={newDeal.contact}
                  onChange={(e) => setNewDeal({ ...newDeal, contact: e.target.value })}
                  placeholder="John Smith"
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setAddDealOpen(false)}>Cancel</Button>
              <Button onClick={handleAddDeal}>Add Deal</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </main>

      <BottomNav />
    </div>
  );
}
