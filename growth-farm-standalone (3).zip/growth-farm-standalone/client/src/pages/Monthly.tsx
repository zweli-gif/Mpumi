import { useState, useMemo } from "react";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { PageHeader } from "@/components/PageHeader";
import { BottomNav } from "@/components/BottomNav";
import { Users, Target, Rocket, Shield, Compass, Loader2, Lock, Plus } from "lucide-react";
import { toast } from "sonner";

const STRATEGIC_OBJECTIVES = [
  { id: "community-growth", name: "Community Growth", icon: Users, color: "text-green-600 bg-green-100" },
  { id: "impact-delivery", name: "Impact Delivery", icon: Target, color: "text-blue-600 bg-blue-100" },
  { id: "new-frontiers", name: "New Frontiers", icon: Rocket, color: "text-purple-600 bg-purple-100" },
  { id: "stewardship", name: "Stewardship", icon: Shield, color: "text-amber-600 bg-amber-100" },
  { id: "purpose-platform", name: "Purpose & Platform", icon: Compass, color: "text-rose-600 bg-rose-100" },
];

const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

function getPerformanceIndicator(actual: number, target: number): { color: string; icon: React.ReactNode; label: string } {
  if (target === 0) return { color: "text-muted-foreground", icon: null, label: "-" };
  const percentage = (actual / target) * 100;
  if (percentage >= 75) return { color: "text-green-600", icon: <span className="text-green-600">🟢</span>, label: `${percentage.toFixed(0)}%` };
  if (percentage >= 60) return { color: "text-yellow-600", icon: <span className="text-yellow-600">🟡</span>, label: `${percentage.toFixed(0)}%` };
  return { color: "text-red-600", icon: <span className="text-red-600">🔴</span>, label: `${percentage.toFixed(0)}%` };
}

function isMonthLocked(month: number, year: number): boolean {
  const now = new Date();
  const currentMonth = now.getMonth() + 1;
  const currentYear = now.getFullYear();
  if (year < currentYear) return true;
  if (year > currentYear) return false;
  if (month > currentMonth) return false;
  if (month < currentMonth) return true;
  return false;
}

interface KPIRow {
  id: number;
  name: string;
  annualTarget: number;
  unit: string;
  owner: string;
  strategicObjective: string;
  monthlyTargets: { month: number; target: number; actual: number; isLocked: boolean }[];
}

const MOCK_KPIS: KPIRow[] = [
  { id: 1, name: "Revenue", annualTarget: 24000000, unit: "R", owner: "Zweli", strategicObjective: "community-growth",
    monthlyTargets: MONTHS.map((_, i) => ({ month: i + 1, target: 2000000, actual: i < 1 ? 1800000 : 0, isLocked: isMonthLocked(i + 1, 2026) })) },
  { id: 2, name: "New Clients", annualTarget: 12, unit: "#", owner: "Zweli", strategicObjective: "community-growth",
    monthlyTargets: MONTHS.map((_, i) => ({ month: i + 1, target: 1, actual: i < 1 ? 1 : 0, isLocked: isMonthLocked(i + 1, 2026) })) },
  { id: 3, name: "Project Delivery Rate", annualTarget: 95, unit: "%", owner: "Albert", strategicObjective: "impact-delivery",
    monthlyTargets: MONTHS.map((_, i) => ({ month: i + 1, target: 95, actual: i < 1 ? 92 : 0, isLocked: isMonthLocked(i + 1, 2026) })) },
  { id: 4, name: "Client NPS", annualTarget: 80, unit: "#", owner: "Albert", strategicObjective: "impact-delivery",
    monthlyTargets: MONTHS.map((_, i) => ({ month: i + 1, target: 80, actual: i < 1 ? 85 : 0, isLocked: isMonthLocked(i + 1, 2026) })) },
  { id: 5, name: "Active Ventures", annualTarget: 5, unit: "#", owner: "Zweli", strategicObjective: "new-frontiers",
    monthlyTargets: MONTHS.map((_, i) => ({ month: i + 1, target: i < 6 ? 3 : 5, actual: i < 1 ? 3 : 0, isLocked: isMonthLocked(i + 1, 2026) })) },
  { id: 6, name: "Cash Reserves", annualTarget: 1000000, unit: "R", owner: "Lindiwe", strategicObjective: "stewardship",
    monthlyTargets: MONTHS.map((_, i) => ({ month: i + 1, target: Math.round(1000000 * ((i + 1) / 12)), actual: i < 1 ? 250000 : 0, isLocked: isMonthLocked(i + 1, 2026) })) },
  { id: 7, name: "Team Health Score", annualTarget: 80, unit: "%", owner: "Brian", strategicObjective: "purpose-platform",
    monthlyTargets: MONTHS.map((_, i) => ({ month: i + 1, target: 80, actual: i < 1 ? 75 : 0, isLocked: isMonthLocked(i + 1, 2026) })) },
];

export default function Monthly() {
  const { loading } = useAuth();
  const [activeTab, setActiveTab] = useState("community-growth");
  const [kpis, setKpis] = useState<KPIRow[]>(MOCK_KPIS);
  const [editingCell, setEditingCell] = useState<{ kpiId: number; month: number; field: "target" | "actual" } | null>(null);
  const [editValue, setEditValue] = useState("");
  const [addKPIDialogOpen, setAddKPIDialogOpen] = useState(false);
  const [newKPI, setNewKPI] = useState({ name: "", annualTarget: "", unit: "R", owner: "" });

  const currentMonth = new Date().getMonth() + 1;
  const currentYear = new Date().getFullYear();

  const filteredKPIs = useMemo(() => kpis.filter((kpi) => kpi.strategicObjective === activeTab), [kpis, activeTab]);

  const formatValue = (value: number, unit: string): string => {
    if (unit === "R") {
      if (value >= 1000000) return `R${(value / 1000000).toFixed(1)}M`;
      if (value >= 1000) return `R${(value / 1000).toFixed(0)}K`;
      return `R${value}`;
    }
    if (unit === "%") return `${value}%`;
    return `${value}`;
  };

  const handleCellClick = (kpiId: number, month: number, field: "target" | "actual", currentValue: number, isLocked: boolean) => {
    if (isLocked && field === "actual") {
      toast.error("This month is locked. Actuals cannot be edited after the 5th of the following month.");
      return;
    }
    setEditingCell({ kpiId, month, field });
    setEditValue(currentValue.toString());
  };

  const handleCellSave = () => {
    if (!editingCell) return;
    const numValue = parseFloat(editValue) || 0;
    setKpis((prev) => prev.map((kpi) => {
      if (kpi.id !== editingCell.kpiId) return kpi;
      return { ...kpi, monthlyTargets: kpi.monthlyTargets.map((mt) => {
        if (mt.month !== editingCell.month) return mt;
        return { ...mt, [editingCell.field]: numValue };
      }) };
    }));
    setEditingCell(null);
    toast.success("Value updated");
  };

  const handleAddKPI = () => {
    if (!newKPI.name || !newKPI.annualTarget) { toast.error("Please fill in all fields"); return; }
    const annualTarget = parseFloat(newKPI.annualTarget);
    const monthlyTarget = annualTarget / 12;
    const newKPIRow: KPIRow = {
      id: Date.now(), name: newKPI.name, annualTarget, unit: newKPI.unit, owner: newKPI.owner || "Unassigned", strategicObjective: activeTab,
      monthlyTargets: MONTHS.map((_, i) => ({ month: i + 1, target: Math.round(monthlyTarget * 100) / 100, actual: 0, isLocked: isMonthLocked(i + 1, currentYear) })),
    };
    setKpis((prev) => [...prev, newKPIRow]);
    setNewKPI({ name: "", annualTarget: "", unit: "R", owner: "" });
    setAddKPIDialogOpen(false);
    toast.success("KPI added successfully");
  };

  const calculateYTD = (kpi: KPIRow) => kpi.monthlyTargets.filter((mt) => mt.month <= currentMonth).reduce((acc, mt) => ({ target: acc.target + mt.target, actual: acc.actual + mt.actual }), { target: 0, actual: 0 });

  if (loading) return <div className="min-h-screen bg-background flex items-center justify-center"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>;

  const activeObjective = STRATEGIC_OBJECTIVES.find((obj) => obj.id === activeTab);

  return (
    <div className="min-h-screen bg-background pb-20 md:pb-0">
      <PageHeader title="MONTHLY TARGETS" subtitle={`${currentYear} KPI Cascade`} />
      <main className="container py-4 space-y-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <Card className="p-3"><div className="text-xs text-muted-foreground">Current Month</div><div className="text-lg font-bold">{MONTHS[currentMonth - 1]} {currentYear}</div></Card>
          <Card className="p-3"><div className="text-xs text-muted-foreground">Active KPIs</div><div className="text-lg font-bold">{kpis.length}</div></Card>
          <Card className="p-3"><div className="text-xs text-muted-foreground">On Track</div><div className="text-lg font-bold text-green-600">{kpis.filter((kpi) => { const ytd = calculateYTD(kpi); return ytd.target > 0 && (ytd.actual / ytd.target) >= 0.75; }).length}</div></Card>
          <Card className="p-3"><div className="text-xs text-muted-foreground">Needs Attention</div><div className="text-lg font-bold text-red-600">{kpis.filter((kpi) => { const ytd = calculateYTD(kpi); return ytd.target > 0 && (ytd.actual / ytd.target) < 0.60; }).length}</div></Card>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="w-full flex overflow-x-auto">
            {STRATEGIC_OBJECTIVES.map((obj) => { const Icon = obj.icon; return (
              <TabsTrigger key={obj.id} value={obj.id} className="flex-1 min-w-[100px] gap-1 text-xs">
                <Icon className="h-3 w-3" /><span className="hidden sm:inline">{obj.name}</span><span className="sm:hidden">{obj.name.split(" ")[0]}</span>
              </TabsTrigger>
            ); })}
          </TabsList>

          {STRATEGIC_OBJECTIVES.map((obj) => (
            <TabsContent key={obj.id} value={obj.id} className="mt-4">
              <Card>
                <CardHeader className="pb-3 flex flex-row items-center justify-between">
                  <div className="flex items-center gap-2"><obj.icon className={`h-5 w-5 ${obj.color.split(" ")[0]}`} /><CardTitle className="text-base">{obj.name}</CardTitle></div>
                  <Button size="sm" variant="outline" onClick={() => setAddKPIDialogOpen(true)}><Plus className="h-4 w-4 mr-1" />Add KPI</Button>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto -mx-4 px-4">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="border-b">
                          <th className="text-left py-2 px-2 font-medium sticky left-0 bg-card min-w-[120px]">KPI</th>
                          <th className="text-right py-2 px-2 font-medium min-w-[70px]">Annual</th>
                          {MONTHS.map((month, i) => (
                            <th key={month} className={`text-center py-2 px-1 font-medium min-w-[60px] ${i + 1 === currentMonth ? "bg-primary/10" : ""}`}>
                              {month}{isMonthLocked(i + 1, currentYear) && <Lock className="h-3 w-3 inline ml-1 text-muted-foreground" />}
                            </th>
                          ))}
                          <th className="text-center py-2 px-2 font-medium min-w-[60px]">YTD</th>
                        </tr>
                      </thead>
                      <tbody>
                        {filteredKPIs.length === 0 ? (
                          <tr><td colSpan={15} className="text-center py-8 text-muted-foreground">No KPIs for this objective. Click "Add KPI" to create one.</td></tr>
                        ) : filteredKPIs.map((kpi) => {
                          const ytd = calculateYTD(kpi);
                          const ytdPerf = getPerformanceIndicator(ytd.actual, ytd.target);
                          return (
                            <tr key={kpi.id} className="border-b hover:bg-muted/30">
                              <td className="py-2 px-2 sticky left-0 bg-card"><div className="font-medium">{kpi.name}</div><div className="text-xs text-muted-foreground">{kpi.owner}</div></td>
                              <td className="text-right py-2 px-2 font-medium">{formatValue(kpi.annualTarget, kpi.unit)}</td>
                              {kpi.monthlyTargets.map((mt) => {
                                const perf = mt.actual > 0 ? getPerformanceIndicator(mt.actual, mt.target) : null;
                                const isEditing = editingCell?.kpiId === kpi.id && editingCell?.month === mt.month;
                                const isCurrent = mt.month === currentMonth;
                                return (
                                  <td key={mt.month} className={`py-1 px-1 ${isCurrent ? "bg-primary/10" : ""}`}>
                                    <div className="text-xs text-center bg-muted/50 rounded px-1 py-0.5 cursor-pointer hover:bg-muted" onClick={() => handleCellClick(kpi.id, mt.month, "target", mt.target, false)}>
                                      {isEditing && editingCell.field === "target" ? (
                                        <Input autoFocus value={editValue} onChange={(e) => setEditValue(e.target.value)} onBlur={handleCellSave} onKeyDown={(e) => e.key === "Enter" && handleCellSave()} className="h-5 text-xs p-1 text-center" />
                                      ) : formatValue(mt.target, kpi.unit)}
                                    </div>
                                    <div className={`text-xs text-center mt-1 rounded px-1 py-0.5 ${mt.isLocked ? "cursor-not-allowed opacity-60" : "cursor-pointer hover:bg-muted/50"}`} onClick={() => handleCellClick(kpi.id, mt.month, "actual", mt.actual, mt.isLocked)}>
                                      {isEditing && editingCell.field === "actual" ? (
                                        <Input autoFocus value={editValue} onChange={(e) => setEditValue(e.target.value)} onBlur={handleCellSave} onKeyDown={(e) => e.key === "Enter" && handleCellSave()} className="h-5 text-xs p-1 text-center" />
                                      ) : <span className="flex items-center justify-center gap-1">{mt.actual > 0 && perf?.icon}{mt.actual > 0 ? formatValue(mt.actual, kpi.unit) : "-"}</span>}
                                    </div>
                                  </td>
                                );
                              })}
                              <td className="py-2 px-2 text-center">
                                <div className="flex items-center justify-center gap-1">{ytdPerf.icon}<span className={ytdPerf.color}>{ytdPerf.label}</span></div>
                                <div className="text-xs text-muted-foreground">{formatValue(ytd.actual, kpi.unit)} / {formatValue(ytd.target, kpi.unit)}</div>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                  <div className="flex items-center gap-4 mt-4 text-xs text-muted-foreground">
                    <span className="flex items-center gap-1">🟢 ≥75%</span>
                    <span className="flex items-center gap-1">🟡 60-74%</span>
                    <span className="flex items-center gap-1">🔴 &lt;60%</span>
                    <span className="flex items-center gap-1"><Lock className="h-3 w-3" /> Locked</span>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          ))}
        </Tabs>
      </main>

      <Dialog open={addKPIDialogOpen} onOpenChange={setAddKPIDialogOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Add New KPI</DialogTitle><DialogDescription>Add a KPI to {activeObjective?.name}. Monthly targets will be auto-generated.</DialogDescription></DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2"><Label>KPI Name</Label><Input value={newKPI.name} onChange={(e) => setNewKPI({ ...newKPI, name: e.target.value })} placeholder="e.g., Revenue, Client Count" /></div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2"><Label>Annual Target</Label><Input type="number" value={newKPI.annualTarget} onChange={(e) => setNewKPI({ ...newKPI, annualTarget: e.target.value })} placeholder="24000000" /></div>
              <div className="space-y-2"><Label>Unit</Label><Select value={newKPI.unit} onValueChange={(v) => setNewKPI({ ...newKPI, unit: v })}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="R">R (Rands)</SelectItem><SelectItem value="%">% (Percentage)</SelectItem><SelectItem value="#"># (Count)</SelectItem></SelectContent></Select></div>
            </div>
            <div className="space-y-2"><Label>EXCO Owner</Label><Input value={newKPI.owner} onChange={(e) => setNewKPI({ ...newKPI, owner: e.target.value })} placeholder="e.g., Zweli, Albert" /></div>
          </div>
          <DialogFooter><Button variant="outline" onClick={() => setAddKPIDialogOpen(false)}>Cancel</Button><Button onClick={handleAddKPI}>Add KPI</Button></DialogFooter>
        </DialogContent>
      </Dialog>

      <BottomNav />
    </div>
  );
}
