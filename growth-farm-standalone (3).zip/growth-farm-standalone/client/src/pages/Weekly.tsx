import { useState, useMemo } from "react";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { PageHeader } from "@/components/PageHeader";
import { BottomNav } from "@/components/BottomNav";
import { trpc } from "@/lib/trpc";
import { Plus, Trash2, Loader2, Check, Clock, X, Filter, Users, Target, Rocket, Shield, Compass } from "lucide-react";
import { toast } from "sonner";
import { format, startOfWeek, endOfWeek, addDays } from "date-fns";

// Strategic Objectives for dropdown
const STRATEGIC_OBJECTIVES = [
  { id: "none", name: "None", icon: null },
  { id: "community-growth", name: "Community Growth", icon: Users, color: "text-green-600 bg-green-100" },
  { id: "impact-delivery", name: "Impact Delivery", icon: Target, color: "text-blue-600 bg-blue-100" },
  { id: "new-frontiers", name: "New Frontiers", icon: Rocket, color: "text-purple-600 bg-purple-100" },
  { id: "stewardship", name: "Stewardship", icon: Shield, color: "text-amber-600 bg-amber-100" },
  { id: "purpose-platform", name: "Purpose & Platform", icon: Compass, color: "text-rose-600 bg-rose-100" },
];

// Status options
const STATUS_OPTIONS = [
  { value: "pending", label: "Pending", icon: <Clock className="h-3 w-3" />, color: "text-muted-foreground" },
  { value: "done", label: "Done ✓", icon: <Check className="h-3 w-3" />, color: "text-green-600" },
  { value: "delayed", label: "Delayed ⏰", icon: <Clock className="h-3 w-3" />, color: "text-yellow-600" },
  { value: "deprioritised", label: "Deprioritised ✗", icon: <X className="h-3 w-3" />, color: "text-red-600" },
];

// Mock team members
const TEAM_MEMBERS = [
  { id: 1, name: "Zweli" },
  { id: 2, name: "Albert" },
  { id: 3, name: "Brian" },
  { id: 4, name: "Lindiwe" },
  { id: 5, name: "Thabo" },
  { id: 6, name: "Mpumi" },
];

// Days of the week for due date
const DAYS_OF_WEEK = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];

interface ActivityRow {
  id: number;
  activity: string;
  dueDay: string;
  dependencies: number[];
  accountabilityPartner: number | null;
  relevantGoal: string;
  status: "pending" | "done" | "delayed" | "deprioritised";
}

// Generate initial activities
const generateInitialActivities = (): ActivityRow[] => [
  { id: 1, activity: "Finalize Q1 client proposals", dueDay: "Tuesday", dependencies: [2, 3], accountabilityPartner: 2, relevantGoal: "community-growth", status: "pending" },
  { id: 2, activity: "Review venture pitch decks", dueDay: "Wednesday", dependencies: [], accountabilityPartner: 1, relevantGoal: "new-frontiers", status: "done" },
  { id: 3, activity: "Complete financial projections", dueDay: "Thursday", dependencies: [4], accountabilityPartner: 4, relevantGoal: "stewardship", status: "pending" },
  { id: 4, activity: "Team health check-ins", dueDay: "Friday", dependencies: [], accountabilityPartner: 3, relevantGoal: "purpose-platform", status: "delayed" },
  { id: 5, activity: "Client delivery review meeting", dueDay: "Monday", dependencies: [1], accountabilityPartner: 2, relevantGoal: "impact-delivery", status: "pending" },
];

export default function Weekly() {
  const { user, loading } = useAuth();
  const [activities, setActivities] = useState<ActivityRow[]>(generateInitialActivities());
  const [filterStatus, setFilterStatus] = useState<string>("all");
  const [filterGoal, setFilterGoal] = useState<string>("all");
  const [editingId, setEditingId] = useState<number | null>(null);

  const now = new Date();
  const weekStart = startOfWeek(now, { weekStartsOn: 1 });
  const weekEnd = endOfWeek(now, { weekStartsOn: 1 });
  const weekNumber = Math.ceil((now.getTime() - new Date(now.getFullYear(), 0, 1).getTime()) / (7 * 24 * 60 * 60 * 1000));

  // Filter activities
  const filteredActivities = useMemo(() => {
    return activities.filter((a) => {
      if (filterStatus !== "all" && a.status !== filterStatus) return false;
      if (filterGoal !== "all" && a.relevantGoal !== filterGoal) return false;
      return true;
    });
  }, [activities, filterStatus, filterGoal]);

  // Stats
  const stats = useMemo(() => ({
    total: activities.length,
    done: activities.filter((a) => a.status === "done").length,
    pending: activities.filter((a) => a.status === "pending").length,
    delayed: activities.filter((a) => a.status === "delayed").length,
  }), [activities]);

  // Add new row
  const addRow = () => {
    const newActivity: ActivityRow = {
      id: Date.now(),
      activity: "",
      dueDay: "Monday",
      dependencies: [],
      accountabilityPartner: null,
      relevantGoal: "none",
      status: "pending",
    };
    setActivities([...activities, newActivity]);
    setEditingId(newActivity.id);
  };

  // Update activity field
  const updateActivity = (id: number, field: keyof ActivityRow, value: any) => {
    setActivities((prev) =>
      prev.map((a) => (a.id === id ? { ...a, [field]: value } : a))
    );
  };

  // Delete row
  const deleteRow = (id: number) => {
    setActivities((prev) => prev.filter((a) => a.id !== id));
    toast.success("Activity removed");
  };

  // Toggle dependency
  const toggleDependency = (activityId: number, memberId: number) => {
    setActivities((prev) =>
      prev.map((a) => {
        if (a.id !== activityId) return a;
        const deps = a.dependencies.includes(memberId)
          ? a.dependencies.filter((d) => d !== memberId)
          : [...a.dependencies, memberId];
        return { ...a, dependencies: deps };
      })
    );
  };

  // Get strategic objective badge
  const getGoalBadge = (goalId: string) => {
    const obj = STRATEGIC_OBJECTIVES.find((o) => o.id === goalId);
    if (!obj || goalId === "none") return null;
    const Icon = obj.icon;
    return (
      <Badge variant="outline" className={`text-xs ${obj.color}`}>
        {Icon && <Icon className="h-3 w-3 mr-1" />}
        {obj.name.split(" ")[0]}
      </Badge>
    );
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-20 md:pb-0">
      <PageHeader
        title="WEEKLY ACTIVITIES"
        subtitle={`Week ${weekNumber} · ${format(weekStart, "MMM d")} - ${format(weekEnd, "MMM d, yyyy")}`}
      />

      <main className="container py-4 space-y-4">
        {/* Stats Row */}
        <div className="grid grid-cols-4 gap-3">
          <Card className="p-3">
            <div className="text-xs text-muted-foreground">Total</div>
            <div className="text-xl font-bold">{stats.total}</div>
          </Card>
          <Card className="p-3">
            <div className="text-xs text-muted-foreground">Done</div>
            <div className="text-xl font-bold text-green-600">{stats.done}</div>
          </Card>
          <Card className="p-3">
            <div className="text-xs text-muted-foreground">Pending</div>
            <div className="text-xl font-bold text-muted-foreground">{stats.pending}</div>
          </Card>
          <Card className="p-3">
            <div className="text-xs text-muted-foreground">Delayed</div>
            <div className="text-xl font-bold text-yellow-600">{stats.delayed}</div>
          </Card>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap gap-2 items-center">
          <Filter className="h-4 w-4 text-muted-foreground" />
          <Select value={filterStatus} onValueChange={setFilterStatus}>
            <SelectTrigger className="w-[130px] h-8">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              {STATUS_OPTIONS.map((s) => (
                <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={filterGoal} onValueChange={setFilterGoal}>
            <SelectTrigger className="w-[160px] h-8">
              <SelectValue placeholder="Goal" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Goals</SelectItem>
              {STRATEGIC_OBJECTIVES.filter((o) => o.id !== "none").map((o) => (
                <SelectItem key={o.id} value={o.id}>{o.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button size="sm" variant="outline" onClick={addRow} className="ml-auto">
            <Plus className="h-4 w-4 mr-1" />
            Add Activity
          </Button>
        </div>

        {/* Activity Table */}
        <Card>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b bg-muted/30">
                    <th className="text-left py-3 px-3 font-medium min-w-[200px]">Activity</th>
                    <th className="text-left py-3 px-2 font-medium min-w-[100px]">Due Day</th>
                    <th className="text-left py-3 px-2 font-medium min-w-[150px]">Dependencies</th>
                    <th className="text-left py-3 px-2 font-medium min-w-[120px]">Accountability</th>
                    <th className="text-left py-3 px-2 font-medium min-w-[140px]">Goal</th>
                    <th className="text-left py-3 px-2 font-medium min-w-[120px]">Status</th>
                    <th className="text-center py-3 px-2 font-medium w-[50px]"></th>
                  </tr>
                </thead>
                <tbody>
                  {filteredActivities.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="text-center py-8 text-muted-foreground">
                        No activities found. Click "Add Activity" to create one.
                      </td>
                    </tr>
                  ) : (
                    filteredActivities.map((activity) => (
                      <tr key={activity.id} className="border-b hover:bg-muted/20">
                        {/* Activity */}
                        <td className="py-2 px-3">
                          <Input
                            value={activity.activity}
                            onChange={(e) => updateActivity(activity.id, "activity", e.target.value)}
                            placeholder="Enter activity..."
                            className="h-8 border-0 bg-transparent focus:bg-card"
                          />
                        </td>

                        {/* Due Day */}
                        <td className="py-2 px-2">
                          <Select
                            value={activity.dueDay}
                            onValueChange={(v) => updateActivity(activity.id, "dueDay", v)}
                          >
                            <SelectTrigger className="h-8 border-0 bg-transparent">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              {DAYS_OF_WEEK.map((day) => (
                                <SelectItem key={day} value={day}>{day}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </td>

                        {/* Dependencies (multi-select) */}
                        <td className="py-2 px-2">
                          <div className="flex flex-wrap gap-1">
                            {TEAM_MEMBERS.slice(0, 4).map((member) => (
                              <Badge
                                key={member.id}
                                variant={activity.dependencies.includes(member.id) ? "default" : "outline"}
                                className="cursor-pointer text-xs"
                                onClick={() => toggleDependency(activity.id, member.id)}
                              >
                                {member.name.slice(0, 2)}
                              </Badge>
                            ))}
                          </div>
                        </td>

                        {/* Accountability Partner */}
                        <td className="py-2 px-2">
                          <Select
                            value={activity.accountabilityPartner?.toString() || ""}
                            onValueChange={(v) => updateActivity(activity.id, "accountabilityPartner", v ? parseInt(v) : null)}
                          >
                            <SelectTrigger className="h-8 border-0 bg-transparent">
                              <SelectValue placeholder="Select..." />
                            </SelectTrigger>
                            <SelectContent>
                              {TEAM_MEMBERS.map((member) => (
                                <SelectItem key={member.id} value={member.id.toString()}>
                                  {member.name}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </td>

                        {/* Relevant Goal */}
                        <td className="py-2 px-2">
                          <Select
                            value={activity.relevantGoal}
                            onValueChange={(v) => updateActivity(activity.id, "relevantGoal", v)}
                          >
                            <SelectTrigger className="h-8 border-0 bg-transparent">
                              {getGoalBadge(activity.relevantGoal) || <SelectValue placeholder="None" />}
                            </SelectTrigger>
                            <SelectContent>
                              {STRATEGIC_OBJECTIVES.map((obj) => (
                                <SelectItem key={obj.id} value={obj.id}>{obj.name}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </td>

                        {/* Status */}
                        <td className="py-2 px-2">
                          <Select
                            value={activity.status}
                            onValueChange={(v: any) => updateActivity(activity.id, "status", v)}
                          >
                            <SelectTrigger className={`h-8 border-0 bg-transparent ${STATUS_OPTIONS.find((s) => s.value === activity.status)?.color}`}>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              {STATUS_OPTIONS.map((s) => (
                                <SelectItem key={s.value} value={s.value}>
                                  <span className={s.color}>{s.label}</span>
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </td>

                        {/* Delete */}
                        <td className="py-2 px-2 text-center">
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-7 w-7 p-0 text-muted-foreground hover:text-destructive"
                            onClick={() => deleteRow(activity.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>

            {/* Add Row Button (at bottom of table) */}
            <div className="p-2 border-t">
              <Button variant="ghost" size="sm" onClick={addRow} className="w-full text-muted-foreground">
                <Plus className="h-4 w-4 mr-1" />
                Add Activity
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Legend */}
        <div className="flex flex-wrap items-center gap-4 text-xs text-muted-foreground">
          <span>Status:</span>
          {STATUS_OPTIONS.map((s) => (
            <span key={s.value} className={`flex items-center gap-1 ${s.color}`}>
              {s.icon} {s.label}
            </span>
          ))}
        </div>
      </main>

      <BottomNav />
    </div>
  );
}
