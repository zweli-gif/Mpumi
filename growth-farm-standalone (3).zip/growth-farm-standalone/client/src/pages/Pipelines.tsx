import { Redirect } from "wouter";

// Pipelines functionality is now part of Engine
export default function Pipelines() {
  return <Redirect to="/engine" />;
}
