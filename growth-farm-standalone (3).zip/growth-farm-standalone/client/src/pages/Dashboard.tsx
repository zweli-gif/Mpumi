import { useAuth } from "@/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { trpc } from "@/lib/trpc";
import { PageHeader } from "@/components/PageHeader";
import { BottomNav } from "@/components/BottomNav";
import { Logo } from "@/components/Logo";
import { TrendingUp, Users, Target, DollarSign, Loader2, AlertCircle, Building2, Rocket, Palette, Briefcase } from "lucide-react";
import { Link } from "wouter";

export default function Dashboard() {
  const { user, loading, isAuthenticated } = useAuth();

  // Queries
  const { data: teamHealth } = trpc.health.getTeamOverview.useQuery();
  const { data: bdPipeline } = trpc.pipelines.getCards.useQuery({ pipelineType: "bd" });
  const { data: venturesPipeline } = trpc.pipelines.getCards.useQuery({ pipelineType: "ventures" });
  const { data: studioPipeline } = trpc.pipelines.getCards.useQuery({ pipelineType: "studio" });
  const { data: clientsPipeline } = trpc.pipelines.getCards.useQuery({ pipelineType: "clients" });
  const { data: financePipeline } = trpc.pipelines.getCards.useQuery({ pipelineType: "finance" });
  const { data: annualGoals } = trpc.goals.getAnnual.useQuery({ year: 2026 });

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Card className="w-full max-w-md">
          <CardHeader>
            <div className="flex justify-center mb-4">
              <Logo size="lg" linkTo={undefined} />
            </div>
            <CardTitle className="text-2xl text-center">Executive Dashboard</CardTitle>
          </CardHeader>
          <CardContent>
            <Button asChild className="w-full">
              <a href={getLoginUrl()}>Sign In</a>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Calculate metrics
  const bdValue = bdPipeline?.cards.reduce((sum, card) => sum + parseFloat(card.value || "0"), 0) || 0;
  const bdWonStage = bdPipeline?.stages.find(s => s.name === "Won");
  const bdWonValue = bdPipeline?.cards
    .filter(c => c.stageId === bdWonStage?.id)
    .reduce((sum, card) => sum + parseFloat(card.value || "0"), 0) || 0;

  const revenueGoal = annualGoals?.find(g => g.category === "revenue" && g.description === "Annual Revenue");
  const revenueTarget = parseFloat(revenueGoal?.targetValue || "24000000");
  const revenueProgress = (bdWonValue / revenueTarget) * 100;

  // Mock financial metrics
  const cashReserves = 250000;
  const cashTarget = 1000000;
  const cashProgress = (cashReserves / cashTarget) * 100;

  const taxLiability = 85000;
  const taxPaid = 0;
  const taxProgress = taxLiability > 0 ? 100 - ((taxPaid / taxLiability) * 100) : 0;

  const activeVentures = venturesPipeline?.cards.length || 0;
  const activeClients = clientsPipeline?.cards.filter(c => {
    const stage = clientsPipeline.stages.find(s => s.id === c.stageId);
    return stage?.name === "Active";
  }).length || 0;
  const atRiskClients = clientsPipeline?.cards.filter(c => {
    const stage = clientsPipeline.stages.find(s => s.id === c.stageId);
    return stage?.name === "At Risk";
  }).length || 0;

  const studioProjects = studioPipeline?.cards.length || 0;
  const pendingFinance = financePipeline?.cards.filter(c => {
    const stage = financePipeline.stages.find(s => s.id === c.stageId);
    return stage?.name === "Pending";
  }).length || 0;

  // Client relationship types
  const clientTypes = [
    { name: "Strategic Partners", count: 2, value: "R4.2M", icon: Building2, color: "text-purple-600 bg-purple-100" },
    { name: "Active Clients", count: activeClients || 4, value: "R2.8M", icon: Briefcase, color: "text-green-600 bg-green-100" },
    { name: "At Risk", count: atRiskClients || 1, value: "R500K", icon: AlertCircle, color: "text-red-600 bg-red-100" },
    { name: "Prospects", count: 3, value: "R1.5M", icon: Target, color: "text-blue-600 bg-blue-100" },
  ];

  return (
    <div className="min-h-screen bg-background pb-20 md:pb-0">
      <PageHeader title="DASHBOARD" subtitle="Executive Health" showLogo={false} />

      {/* Main Content - Optimized for single laptop screen */}
      <main className="container py-4 space-y-4">
        {/* Row 1: Key Finance Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {/* Team Health */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <Users className="h-4 w-4" />
                Team Health
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex items-baseline gap-2">
                  <span className="text-3xl font-bold">{teamHealth?.overallScore || 0}%</span>
                  <Badge variant="secondary" className="text-xs">
                    {teamHealth?.team.length || 0} members
                  </Badge>
                </div>
                <Progress value={teamHealth?.overallScore || 0} className="h-2" />
              </div>
            </CardContent>
          </Card>

          {/* Revenue YTD */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <DollarSign className="h-4 w-4" />
                Revenue YTD
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex items-baseline gap-2">
                  <span className="text-3xl font-bold">R{(bdWonValue / 1000000).toFixed(1)}M</span>
                  <span className="text-sm text-muted-foreground">/ R{(revenueTarget / 1000000).toFixed(0)}M</span>
                </div>
                <div className="relative h-2 bg-muted rounded-full overflow-hidden">
                  <div className="absolute h-full bg-primary" style={{ width: `${Math.min(revenueProgress, 100)}%` }} />
                  {/* "Should be" marker */}
                  <div className="absolute h-full w-0.5 bg-destructive" style={{ left: `${(new Date().getMonth() + 1) / 12 * 100}%` }} />
                </div>
                <p className="text-xs text-muted-foreground">{revenueProgress.toFixed(1)}% of target</p>
              </div>
            </CardContent>
          </Card>

          {/* Cash Reserves */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <TrendingUp className="h-4 w-4" />
                Cash Reserves
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex items-baseline gap-2">
                  <span className="text-3xl font-bold">R{(cashReserves / 1000).toFixed(0)}K</span>
                  <span className="text-sm text-muted-foreground">/ R{(cashTarget / 1000000).toFixed(0)}M</span>
                </div>
                <Progress value={cashProgress} className="h-2" />
                <p className="text-xs text-muted-foreground">{cashProgress.toFixed(0)}% of Dec target</p>
              </div>
            </CardContent>
          </Card>

          {/* Tax Liability */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <AlertCircle className="h-4 w-4 text-amber-500" />
                Tax Liability
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex items-baseline gap-2">
                  <span className="text-3xl font-bold text-amber-600">R{(taxLiability / 1000).toFixed(0)}K</span>
                  <span className="text-sm text-muted-foreground">outstanding</span>
                </div>
                <div className="relative h-2 bg-amber-200 rounded-full overflow-hidden">
                  <div className="absolute h-full bg-amber-500" style={{ width: `${taxProgress}%` }} />
                </div>
                <p className="text-xs text-muted-foreground">Next payment: Feb 25</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Row 2: BD Pipeline (Full Width) */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium flex items-center justify-between">
              <span className="flex items-center gap-2">
                <TrendingUp className="h-4 w-4" />
                BD Pipeline
              </span>
              <Badge variant="outline">R{(bdValue / 1000000).toFixed(1)}M total</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-7 gap-2">
              {bdPipeline?.stages.map((stage) => {
                const stageCards = bdPipeline.cards.filter(c => c.stageId === stage.id);
                const stageValue = stageCards.reduce((sum, card) => sum + parseFloat(card.value || "0"), 0);
                const isWon = stage.name === "Won";
                const isLost = stage.name === "Lost";
                return (
                  <div 
                    key={stage.id} 
                    className={`text-center p-3 rounded-lg ${
                      isWon ? "bg-green-100" : isLost ? "bg-red-100" : "bg-muted/30"
                    }`}
                  >
                    <p className="text-xs font-medium truncate">{stage.name}</p>
                    <p className={`text-2xl font-bold ${isWon ? "text-green-600" : isLost ? "text-red-600" : ""}`}>
                      {stageCards.length}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      R{stageValue >= 1000000 ? `${(stageValue / 1000000).toFixed(1)}M` : `${(stageValue / 1000).toFixed(0)}K`}
                    </p>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Row 3: Operations Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {/* Ventures */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <Rocket className="h-4 w-4 text-purple-600" />
                New Frontiers
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-1">
                <p className="text-2xl font-bold">{activeVentures || 3}</p>
                <p className="text-xs text-muted-foreground">Active ventures</p>
                <div className="pt-2 space-y-1 text-xs">
                  <p className="truncate">• Mntase! Communities</p>
                  <p className="truncate">• briansfomo</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Studio */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <Palette className="h-4 w-4 text-blue-600" />
                Impact Delivery
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-1">
                <p className="text-2xl font-bold">{studioProjects || 2}</p>
                <p className="text-xs text-muted-foreground">Active projects</p>
                <div className="pt-2">
                  <div className="flex justify-between text-xs">
                    <span>Billing</span>
                    <span className="font-medium">72%</span>
                  </div>
                  <Progress value={72} className="h-1.5 mt-1" />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Client Relationships */}
          <Card className="md:col-span-2">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Client Relationships</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-4 gap-2">
                {clientTypes.map((type) => {
                  const Icon = type.icon;
                  return (
                    <div key={type.name} className={`p-2 rounded-lg text-center ${type.color}`}>
                      <Icon className="h-4 w-4 mx-auto mb-1" />
                      <p className="text-lg font-bold">{type.count}</p>
                      <p className="text-[10px] truncate">{type.name}</p>
                      <p className="text-[10px] font-medium">{type.value}</p>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Row 4: Alerts & Actions */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Alerts & Actions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {atRiskClients > 0 && (
                <div className="flex items-center gap-2 p-2 rounded-lg bg-red-50 text-red-800 text-sm">
                  <AlertCircle className="h-4 w-4" />
                  <span className="font-medium">{atRiskClients} client(s) at risk</span>
                  <Link href="/engine" className="ml-auto text-xs underline">View</Link>
                </div>
              )}
              {pendingFinance > 0 && (
                <div className="flex items-center gap-2 p-2 rounded-lg bg-yellow-50 text-yellow-800 text-sm">
                  <DollarSign className="h-4 w-4" />
                  <span className="font-medium">{pendingFinance} pending finance item(s)</span>
                  <Link href="/engine" className="ml-auto text-xs underline">View</Link>
                </div>
              )}
              {(teamHealth?.overallScore || 0) < 70 && (
                <div className="flex items-center gap-2 p-2 rounded-lg bg-orange-50 text-orange-800 text-sm">
                  <Users className="h-4 w-4" />
                  <span className="font-medium">Team health below threshold</span>
                  <Link href="/" className="ml-auto text-xs underline">Check In</Link>
                </div>
              )}
              {taxLiability > 0 && (
                <div className="flex items-center gap-2 p-2 rounded-lg bg-amber-50 text-amber-800 text-sm">
                  <AlertCircle className="h-4 w-4" />
                  <span className="font-medium">Tax payment due Feb 25</span>
                  <Link href="/engine" className="ml-auto text-xs underline">View</Link>
                </div>
              )}
              {!atRiskClients && !pendingFinance && (teamHealth?.overallScore || 0) >= 70 && taxLiability <= 0 && (
                <p className="text-sm text-muted-foreground text-center py-2">All systems healthy ✓</p>
              )}
            </div>
          </CardContent>
        </Card>
      </main>

      <BottomNav />
    </div>
  );
}
