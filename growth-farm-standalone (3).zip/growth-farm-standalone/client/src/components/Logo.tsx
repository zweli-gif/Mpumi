import { Link } from "wouter";

interface LogoProps {
  size?: "sm" | "md" | "lg";
  showText?: boolean;
  linkTo?: string;
}

export function Logo({ size = "md", showText = true, linkTo = "/" }: LogoProps) {
  const sizeClasses = {
    sm: "h-6",
    md: "h-8",
    lg: "h-10",
  };

  const content = (
    <div className="flex items-center gap-2">
      <img 
        src="/logo.jpg" 
        alt="Growth Farm" 
        className={`${sizeClasses[size]} w-auto object-contain`}
      />
      {showText && (
        <span className="font-semibold text-foreground tracking-tight hidden md:inline">
          GROWTH FARM
        </span>
      )}
    </div>
  );

  if (linkTo) {
    return (
      <Link href={linkTo} className="flex items-center hover:opacity-80 transition-opacity">
        {content}
      </Link>
    );
  }

  return content;
}
