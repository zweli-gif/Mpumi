import { Link } from "wouter";
import { ArrowLeft } from "lucide-react";
import { Logo } from "./Logo";

interface PageHeaderProps {
  title: string;
  subtitle?: string;
  showBack?: boolean;
  backTo?: string;
  showLogo?: boolean;
  rightContent?: React.ReactNode;
}

export function PageHeader({
  title,
  subtitle,
  showBack = true,
  backTo = "/",
  showLogo = false,
  rightContent,
}: PageHeaderProps) {
  return (
    <header className="sticky top-0 z-50 w-full border-b bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/60">
      <div className="container flex h-14 items-center justify-between">
        <div className="flex items-center gap-4">
          {showBack && (
            <Link
              href={backTo}
              className="flex items-center gap-2 text-muted-foreground hover:text-foreground"
            >
              <ArrowLeft className="h-4 w-4" />
            </Link>
          )}
          {showLogo ? (
            <Logo size="sm" showText={true} linkTo={undefined} />
          ) : (
            <div>
              <h1 className="text-lg font-semibold">{title}</h1>
              {subtitle && (
                <p className="text-xs text-muted-foreground">{subtitle}</p>
              )}
            </div>
          )}
        </div>
        {rightContent && <div className="flex items-center gap-2">{rightContent}</div>}
      </div>
    </header>
  );
}
