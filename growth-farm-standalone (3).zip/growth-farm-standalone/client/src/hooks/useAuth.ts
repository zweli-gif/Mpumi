import { useState, useEffect } from "react";
import { trpc } from "@/lib/trpc";

export interface User {
  id: number;
  openId: string;
  name: string | null;
  email: string | null;
  role: "user" | "admin";
  avatarUrl: string | null;
  jobTitle: string | null;
  currentHealthScore: number | null;
  currentEnergyLevel: "High" | "Med" | "Low" | null;
}

// Simple auth hook that works with the mock auth system
export function useAuth() {
  const [loading, setLoading] = useState(true);
  
  const { data: user, isLoading, refetch } = trpc.auth.me.useQuery(undefined, {
    retry: false,
    refetchOnWindowFocus: false,
  });

  useEffect(() => {
    if (!isLoading) {
      setLoading(false);
    }
  }, [isLoading]);

  return {
    user: user as User | null,
    loading,
    isAuthenticated: !!user,
    refetch,
  };
}
