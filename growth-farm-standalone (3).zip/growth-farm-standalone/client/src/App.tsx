import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import Dashboard from "./pages/Dashboard";
import Engine from "./pages/Engine";
import Weekly from "./pages/Weekly";
import Monthly from "./pages/Monthly";
import Pipelines from "./pages/Pipelines";
import Trends from "./pages/Trends";
import Settings from "./pages/Settings";
import Login from "./pages/Login";

function Router() {
  return (
    <Switch>
      <Route path={"/"} component={Home} />
      <Route path={"/login"} component={Login} />
      <Route path={"/dashboard"} component={Dashboard} />
      <Route path={"/engine"} component={Engine} />
      <Route path={"/weekly"} component={Weekly} />
      <Route path={"/monthly"} component={Monthly} />
      <Route path={"/pipelines"} component={Pipelines} />
      <Route path={"/trends"} component={Trends} />
      <Route path={"/settings"} component={Settings} />
      <Route path={"/404"} component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
