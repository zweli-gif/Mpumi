# Growth Farm Executive Dashboard - WIP Context Document

**Generated:** February 1, 2026  
**Status:** Sprint 2-3 Implementation Complete  
**Tech Stack:** React + TypeScript + Vite + tRPC + Drizzle ORM + SQLite

---

## IMPLEMENTATION STATUS

### ✅ COMPLETED (Sprints 1-3)

#### Sprint 1: Foundation (Complete)
- [x] Logo integration (`/client/public/logo.jpg` + `Logo.tsx` component)
- [x] Team Management (Settings → Team tab)
- [x] Company Info (Settings → Company tab)
- [x] Annual Goals (Settings → Objectives tab with Strategic Objectives)
- [x] Shared components: `PageHeader.tsx`, `BottomNav.tsx`, `Logo.tsx`

#### Sprint 2: Monthly & Weekly (Complete)
- [x] **Monthly KPI Targets** (`/client/src/pages/Monthly.tsx`)
  - Tabs for each Strategic Objective
  - Table: KPI Name | Annual Target | Jan-Dec columns
  - Monthly targets: grey background (editable)
  - Actual values: input with performance indicators (🟢 ≥75%, 🟡 60-74%, 🔴 <60%)
  - Lock mechanism: Previous months locked
  - Auto-generation: Annual ÷ 12
  - YTD summary column

- [x] **Weekly Activity Tracker** (`/client/src/pages/Weekly.tsx`)
  - Excel-like table with columns:
    - Activity (text input)
    - Due Day (dropdown)
    - Dependencies (multi-select badges)
    - Accountability Partner (dropdown)
    - Relevant Monthly Goal (dropdown with Strategic Objective badges)
    - Status (Done ✓, Delayed ⏰, Deprioritised ✗, Pending)
  - Add row, inline edit, delete on hover
  - Filter by status/partner/goal

#### Sprint 3: Engine (Complete)
- [x] **Engine 6-Tile Modal** (`/client/src/pages/Engine.tsx`)
  - 2x3 tile grid: BD Pipeline 📈, Ventures 🚀, Studio 🎨, Delivery 👥, Finance 💰, Admin ⚙️
  - Bottom sheet expansion on tile click
  
- [x] **BD Pipeline Kanban**
  - Stages: Lead → Discovery → Proposal → Negotiation → Contracting → Won/Lost
  - Card fields: Client Name, Deal Value, Contact Person, Next Action, Days in Stage, Owner
  - Stage summary with counts and values
  - Move cards between stages

- [x] **Ventures Tracking**
  - Columns: Venture Name, Stage, Burn Rate, Target Burn, Days to Revenue, Runway, Key Metrics
  - Stages: Ideation → Validation → MVP → Growth → Scale

- [x] **Studio Tracking**
  - Columns: Project Name, Client, Billing vs Target (progress bar), Timeline Status, End Date, Progress %

- [x] **Delivery Health**
  - Client, Project, Health status (🟢/🟡), Next Milestone, Due Date

- [x] **Finance Overview**
  - Type badges (Invoice, Expense, Tax, Payroll)
  - Amount with color coding (+green/-red)
  - Status badges, Due dates

#### Sprint 4: Dashboard (Complete)
- [x] **Finance Bars** (`/client/src/pages/Dashboard.tsx`)
  - Revenue YTD: Bar 0 → R24M with "should be" red marker line
  - Cash Reserves: Bar 0 → R1M (Dec target)
  - Tax Liability: Amber bar showing outstanding

- [x] **BD Pipeline Full Row**
  - All 7 stages in horizontal row
  - Count + Value for each stage
  - Won (green) / Lost (red) highlighting

- [x] **Client Relationship Cards**
  - Types: Strategic Partners, Active Clients, At Risk, Prospects
  - All types shown even if count = 0
  - Display: Count + Total Value at Stake

- [x] **Alerts & Actions**
  - At-risk clients alert
  - Pending finance items alert
  - Team health below threshold alert
  - Tax payment reminder

---

## NEW NOMENCLATURE APPLIED

| Traditional | Growth Farm Name | Used In |
|-------------|------------------|---------|
| BD & Marketing | Community Growth | Monthly, Weekly, Engine |
| Client Projects | Impact Delivery | Monthly, Weekly, Engine |
| Ventures | New Frontiers | Monthly, Weekly, Engine, Dashboard |
| Finance | Stewardship | Monthly, Weekly, Engine |
| Admin & Ops | Purpose & Platform | Monthly, Weekly, Engine |
| Dashboard | (kept as Dashboard) | Dashboard page |
| Home Page | (kept as Home) | Home page |

---

## FILE STRUCTURE

```
client/src/
├── components/
│   ├── BottomNav.tsx          # Shared 6-button mobile nav
│   ├── Logo.tsx               # Logo component with sizes
│   ├── PageHeader.tsx         # Shared header with back nav
│   └── ui/                    # Radix UI components
├── pages/
│   ├── Home.tsx               # 788 lines - Mood check-ins, celebrations, priorities
│   ├── Dashboard.tsx          # 336 lines - Executive overview with finance bars
│   ├── Engine.tsx             # 422 lines - 6-tile operations hub
│   ├── Monthly.tsx            # 282 lines - KPI cascade table
│   ├── Weekly.tsx             # 310 lines - Activity tracker
│   ├── Settings.tsx           # 620 lines - Team, Objectives, Company
│   ├── Login.tsx              # Auth page
│   ├── Pipelines.tsx          # Redirects to /engine
│   └── Trends.tsx             # Redirects to /dashboard
└── App.tsx                    # Router configuration
```

---

## DATABASE SCHEMA (server/schema.ts)

### Existing Tables (Working)
- `users` - Team members with roles
- `healthCheckins` - Mood tracking
- `weeklyPriorities` - Activity tracking
- `celebrations` - Team celebrations
- `pipelineStages` - BD, Ventures, Studio, Clients, Finance, Admin stages
- `pipelineCards` - Cards for all pipeline types
- `annualGoals` - KPI definitions
- `monthlyTargets` - Monthly breakdowns
- `performanceSnapshots` - Historical data
- `activityLog` - Audit trail
- `systemSettings` - App configuration
- `ceoReflections` - Weekly notes

### Tables Needed (For Full Persistence)
- `companySettings` - Name, tagline, mission (currently hardcoded)
- `ventures` - Detailed venture tracking
- `studioProjects` - Project delivery tracking
- `clients` - Client relationship management
- `clientRelationshipTypes` - Type definitions

---

## MOCK DATA LOCATIONS

Most pages currently use mock data for demonstration:
- **Monthly.tsx**: `MOCK_KPIS` array (line ~40)
- **Weekly.tsx**: `generateInitialActivities()` function
- **Engine.tsx**: `MOCK_BD_CARDS`, `MOCK_VENTURES`, `MOCK_STUDIO`, `MOCK_DELIVERY`, `MOCK_FINANCE`
- **Dashboard.tsx**: Inline mock values for finance metrics

---

## API ROUTES (server/routers.ts)

Working tRPC routers:
- `auth` - Login/session management
- `health` - Team health check-ins
- `priorities` - Weekly priorities CRUD
- `celebrations` - Celebrations CRUD
- `pipelines` - All 6 pipeline types (BD, ventures, studio, clients, finance, admin)
- `goals` - Annual goals + monthly cascade
- `activity` - Activity logging
- `users` - User management
- `ceoReflections` - CEO weekly notes

---

## REMAINING WORK

### Priority Items
1. **Backend Persistence**: Connect Monthly/Weekly pages to tRPC for save
2. **Real-time Sync**: Add optimistic updates and invalidation
3. **Lock Mechanism**: Implement actual date-based locking in backend
4. **Validation**: Sum of monthly targets = annual target

### Nice-to-Have
1. Drag-and-drop for BD Pipeline Kanban
2. Charts/graphs in Dashboard
3. Export to CSV/Excel
4. Notifications system
5. Dark mode polish

---

## TO CONTINUE DEVELOPMENT

1. Install dependencies: `npm install --ignore-scripts`
2. Set up SQLite: The DB file will be created on first run
3. Run dev server: `npm run dev`
4. Access at: `http://localhost:5000`

### Environment Variables
```env
NODE_ENV=development
SESSION_SECRET=your-secret-here
```

---

## BRAND ASSETS

- **Logo**: `/client/public/logo.jpg`
- **Colors**: Earth browns (#3E2723, #5D4037, #8D6E63), Dusty pink (#D4A5A5), Cream (#FAF8F5)
- **Fonts**: Playfair Display (headings), Inter (body)
- **CSS Variables**: Defined in `/client/src/index.css`

---

## KEY DECISIONS

1. **Mobile-first with desktop support** - 6-button bottom nav on mobile, sidebar on desktop
2. **Mock data first** - Enables rapid UI iteration before backend integration
3. **Shared components** - BottomNav, PageHeader, Logo for consistency
4. **New nomenclature** - Applied to operational areas but kept Dashboard/Home names
5. **Bottom sheet pattern** - Used for Engine tile expansion on mobile

---

*Last updated: February 1, 2026*
