export const COOKIE_NAME = "auth_session";
export const ONE_YEAR_MS = 365 * 24 * 60 * 60 * 1000;

// Simple login page URL
export const getLoginUrl = () => "/login";
