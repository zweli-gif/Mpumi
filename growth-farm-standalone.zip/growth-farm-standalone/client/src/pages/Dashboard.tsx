import { useAuth } from "@/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { trpc } from "@/lib/trpc";
import { Home, TrendingUp, Users, Target, DollarSign, Loader2, ArrowLeft, LayoutDashboard, Cog, Calendar, CalendarDays, Settings } from "lucide-react";
import { Link } from "wouter";

export default function Dashboard() {
  const { user, loading, isAuthenticated } = useAuth();

  // Queries
  const { data: teamHealth } = trpc.health.getTeamOverview.useQuery();
  const { data: bdPipeline } = trpc.pipelines.getCards.useQuery({ pipelineType: "bd" });
  const { data: venturesPipeline } = trpc.pipelines.getCards.useQuery({ pipelineType: "ventures" });
  const { data: studioPipeline } = trpc.pipelines.getCards.useQuery({ pipelineType: "studio" });
  const { data: clientsPipeline } = trpc.pipelines.getCards.useQuery({ pipelineType: "clients" });
  const { data: financePipeline } = trpc.pipelines.getCards.useQuery({ pipelineType: "finance" });
  const { data: annualGoals } = trpc.goals.getAnnual.useQuery({ year: 2026 });

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle className="text-2xl">Growth Farm Dashboard</CardTitle>
          </CardHeader>
          <CardContent>
            <Button asChild className="w-full">
              <a href={getLoginUrl()}>Sign In</a>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Calculate metrics
  const bdValue = bdPipeline?.cards.reduce((sum, card) => sum + parseFloat(card.value || "0"), 0) || 0;
  const bdWonStage = bdPipeline?.stages.find(s => s.name === "Won");
  const bdWonValue = bdPipeline?.cards
    .filter(c => c.stageId === bdWonStage?.id)
    .reduce((sum, card) => sum + parseFloat(card.value || "0"), 0) || 0;

  const revenueGoal = annualGoals?.find(g => g.category === "revenue" && g.description === "Annual Revenue");
  const revenueTarget = parseFloat(revenueGoal?.targetValue || "24000000");
  const revenueProgress = (bdWonValue / revenueTarget) * 100;

  const activeVentures = venturesPipeline?.cards.length || 0;
  const activeClients = clientsPipeline?.cards.filter(c => {
    const stage = clientsPipeline.stages.find(s => s.id === c.stageId);
    return stage?.name === "Active";
  }).length || 0;
  const atRiskClients = clientsPipeline?.cards.filter(c => {
    const stage = clientsPipeline.stages.find(s => s.id === c.stageId);
    return stage?.name === "At Risk";
  }).length || 0;

  const studioProjects = studioPipeline?.cards.length || 0;
  const pendingFinance = financePipeline?.cards.filter(c => {
    const stage = financePipeline.stages.find(s => s.id === c.stageId);
    return stage?.name === "Pending";
  }).length || 0;

  return (
    <div className="min-h-screen bg-background pb-20 md:pb-0">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/60">
        <div className="container flex h-14 items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/" className="flex items-center gap-2 text-muted-foreground hover:text-foreground">
              <ArrowLeft className="h-4 w-4" />
            </Link>
            <h1 className="text-lg font-semibold">DASHBOARD</h1>
          </div>
        </div>
      </header>

      {/* Main Content - Optimized for single laptop screen */}
      <main className="container py-4 space-y-4">
        {/* Top Row: Health + Revenue + Pipeline */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Team Health */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <Users className="h-4 w-4" />
                Team Health
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex items-baseline gap-2">
                  <span className="text-3xl font-bold">{teamHealth?.overallScore || 0}%</span>
                  <Badge variant="secondary" className="text-xs">
                    {teamHealth?.team.length || 0} members
                  </Badge>
                </div>
                <Progress value={teamHealth?.overallScore || 0} className="h-2" />
              </div>
            </CardContent>
          </Card>

          {/* Revenue */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <DollarSign className="h-4 w-4" />
                Revenue (YTD)
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex items-baseline gap-2">
                  <span className="text-3xl font-bold">R{(bdWonValue / 1000000).toFixed(1)}M</span>
                  <span className="text-sm text-muted-foreground">/ R{(revenueTarget / 1000000).toFixed(0)}M</span>
                </div>
                <Progress value={revenueProgress} className="h-2" />
                <p className="text-xs text-muted-foreground">{revenueProgress.toFixed(1)}% of annual target</p>
              </div>
            </CardContent>
          </Card>

          {/* Pipeline Value */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <TrendingUp className="h-4 w-4" />
                BD Pipeline
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex items-baseline gap-2">
                  <span className="text-3xl font-bold">R{(bdValue / 1000000).toFixed(1)}M</span>
                  <Badge variant="outline" className="text-xs">
                    {bdPipeline?.cards.length || 0} deals
                  </Badge>
                </div>
                <p className="text-xs text-muted-foreground">Total pipeline value</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Middle Row: Pipeline Stages (Compact) */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">BD Pipeline Stages</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-7 gap-2">
              {bdPipeline?.stages.map((stage) => {
                const stageCards = bdPipeline.cards.filter(c => c.stageId === stage.id);
                const stageValue = stageCards.reduce((sum, card) => sum + parseFloat(card.value || "0"), 0);
                return (
                  <div key={stage.id} className="text-center p-2 rounded-lg bg-muted/30">
                    <p className="text-xs font-medium truncate">{stage.name}</p>
                    <p className="text-lg font-bold">{stageCards.length}</p>
                    <p className="text-xs text-muted-foreground">R{(stageValue / 1000).toFixed(0)}K</p>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Bottom Row: Ventures, Studio, Clients, Finance */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {/* Ventures */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Ventures</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-1">
                <p className="text-2xl font-bold">{activeVentures}</p>
                <p className="text-xs text-muted-foreground">Active ventures</p>
                <div className="pt-2 space-y-1">
                  {venturesPipeline?.cards.slice(0, 2).map((card) => (
                    <p key={card.id} className="text-xs truncate">{card.title}</p>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Studio */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Studio</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-1">
                <p className="text-2xl font-bold">{studioProjects}</p>
                <p className="text-xs text-muted-foreground">Active projects</p>
                <div className="pt-2 space-y-1">
                  {studioPipeline?.cards.slice(0, 2).map((card) => (
                    <p key={card.id} className="text-xs truncate">{card.title}</p>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Clients */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Clients</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-1">
                <p className="text-2xl font-bold">{activeClients}</p>
                <p className="text-xs text-muted-foreground">Active clients</p>
                {atRiskClients > 0 && (
                  <Badge variant="destructive" className="text-xs mt-2">
                    {atRiskClients} at risk
                  </Badge>
                )}
                <div className="pt-2 space-y-1">
                  {clientsPipeline?.cards.slice(0, 2).map((card) => (
                    <p key={card.id} className="text-xs truncate">{card.title}</p>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Finance */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Finance</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-1">
                <p className="text-2xl font-bold">{pendingFinance}</p>
                <p className="text-xs text-muted-foreground">Pending items</p>
                <div className="pt-2 space-y-1">
                  {financePipeline?.cards.slice(0, 2).map((card) => (
                    <p key={card.id} className="text-xs truncate">{card.title}</p>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Alerts & Actions */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Alerts & Actions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {atRiskClients > 0 && (
                <div className="flex items-center gap-2 p-2 rounded-lg bg-red-50 text-red-800 text-sm">
                  <span className="font-medium">{atRiskClients} client(s) at risk</span>
                  <Link href="/pipelines" className="ml-auto text-xs underline">View</Link>
                </div>
              )}
              {pendingFinance > 0 && (
                <div className="flex items-center gap-2 p-2 rounded-lg bg-yellow-50 text-yellow-800 text-sm">
                  <span className="font-medium">{pendingFinance} pending finance item(s)</span>
                  <Link href="/pipelines" className="ml-auto text-xs underline">View</Link>
                </div>
              )}
              {(teamHealth?.overallScore || 0) < 70 && (
                <div className="flex items-center gap-2 p-2 rounded-lg bg-orange-50 text-orange-800 text-sm">
                  <span className="font-medium">Team health below threshold</span>
                  <Link href="/" className="ml-auto text-xs underline">Check In</Link>
                </div>
              )}
              {!atRiskClients && !pendingFinance && (teamHealth?.overallScore || 0) >= 70 && (
                <p className="text-sm text-muted-foreground text-center py-2">All systems healthy ✓</p>
              )}
            </div>
          </CardContent>
        </Card>
      </main>

      {/* Bottom Navigation (Mobile) - 6 buttons */}
      <nav className="fixed bottom-0 left-0 right-0 z-50 border-t bg-card md:hidden">
        <div className="grid grid-cols-6 h-16">
          <Link href="/" className="flex flex-col items-center justify-center gap-1 text-muted-foreground">
            <Home className="h-5 w-5" />
            <span className="text-[10px]">Home</span>
          </Link>
          <Link href="/dashboard" className="flex flex-col items-center justify-center gap-1 text-primary">
            <LayoutDashboard className="h-5 w-5" />
            <span className="text-[10px] font-medium">Dashboard</span>
          </Link>
          <Link href="/engine" className="flex flex-col items-center justify-center gap-1 text-muted-foreground">
            <Cog className="h-5 w-5" />
            <span className="text-[10px]">Engine</span>
          </Link>
          <Link href="/monthly" className="flex flex-col items-center justify-center gap-1 text-muted-foreground">
            <Calendar className="h-5 w-5" />
            <span className="text-[10px]">Monthly</span>
          </Link>
          <Link href="/weekly" className="flex flex-col items-center justify-center gap-1 text-muted-foreground">
            <CalendarDays className="h-5 w-5" />
            <span className="text-[10px]">Weekly</span>
          </Link>
          <Link href="/settings" className="flex flex-col items-center justify-center gap-1 text-muted-foreground">
            <Settings className="h-5 w-5" />
            <span className="text-[10px]">Settings</span>
          </Link>
        </div>
      </nav>
    </div>
  );
}
