import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { CalendarDays, Home as HomeIcon, Calendar, Target, Settings } from "lucide-react";
import { Link } from "wouter";

export default function Weekly() {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Header */}
      <header className="sticky top-0 z-40 border-b bg-card">
        <div className="container flex h-14 items-center justify-between">
          <h1 className="text-lg font-bold tracking-tight">GROWTH FARM</h1>
          <div className="flex items-center gap-2">
            <span className="text-sm text-muted-foreground">Week 5, 2026</span>
          </div>
        </div>
      </header>

      <main className="container py-6 space-y-6">
        <div>
          <h2 className="text-2xl font-bold">Weekly Planning</h2>
          <p className="text-muted-foreground">Set your priorities and track weekly progress</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CalendarDays className="h-5 w-5" />
              This Week's Focus
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground text-center py-8">
              Weekly planning interface coming soon. This is where team members will set their 3 weekly priorities aligned to strategic objectives.
            </p>
          </CardContent>
        </Card>
      </main>

      {/* Bottom Navigation (Mobile) */}
      <nav className="fixed bottom-0 left-0 right-0 z-50 border-t bg-card md:hidden">
        <div className="grid grid-cols-5 h-16">
          <Link href="/" className="flex flex-col items-center justify-center gap-1 text-muted-foreground">
            <HomeIcon className="h-5 w-5" />
            <span className="text-xs">Home</span>
          </Link>
          <Link href="/weekly" className="flex flex-col items-center justify-center gap-1 text-primary">
            <CalendarDays className="h-5 w-5" />
            <span className="text-xs font-medium">Weekly</span>
          </Link>
          <Link href="/monthly" className="flex flex-col items-center justify-center gap-1 text-muted-foreground">
            <Calendar className="h-5 w-5" />
            <span className="text-xs">Monthly</span>
          </Link>
          <Link href="/pipelines" className="flex flex-col items-center justify-center gap-1 text-muted-foreground">
            <Target className="h-5 w-5" />
            <span className="text-xs">Pipelines</span>
          </Link>
          <Link href="/settings" className="flex flex-col items-center justify-center gap-1 text-muted-foreground">
            <Settings className="h-5 w-5" />
            <span className="text-xs">Settings</span>
          </Link>
        </div>
      </nav>
    </div>
  );
}
