import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { trpc } from "@/lib/trpc";
import { Loader2 } from "lucide-react";
import { useLocation } from "wouter";

export default function Login() {
  const [, setLocation] = useLocation();
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const [isAdmin, setIsAdmin] = useState(false);

  const login = trpc.auth.login.useMutation({
    onSuccess: () => {
      setLocation("/");
      window.location.reload();
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !name) return;
    login.mutate({ email, name, role: isAdmin ? "admin" : "user" });
  };

  const quickLogin = (preset: "admin" | "user") => {
    if (preset === "admin") {
      login.mutate({ email: "zweli@growthfarm.africa", name: "Zweli Ntshona", role: "admin" });
    } else {
      login.mutate({ email: "albert@growthfarm.africa", name: "Albert Mokoena", role: "user" });
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="mx-auto mb-4">
            <h1 className="text-3xl font-bold tracking-tight">
              <span className="block">GROWTH</span>
              <span className="block">FARM</span>
            </h1>
          </div>
          <CardTitle className="text-xl">Welcome Back</CardTitle>
          <CardDescription>Sign in to access your dashboard</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Quick Login Buttons */}
          <div className="space-y-2">
            <p className="text-sm text-muted-foreground text-center">Quick Login (Demo)</p>
            <div className="grid grid-cols-2 gap-2">
              <Button 
                variant="outline" 
                onClick={() => quickLogin("admin")}
                disabled={login.isPending}
              >
                {login.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : "Login as CEO"}
              </Button>
              <Button 
                variant="outline" 
                onClick={() => quickLogin("user")}
                disabled={login.isPending}
              >
                {login.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : "Login as Team"}
              </Button>
            </div>
          </div>

          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <span className="w-full border-t" />
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-card px-2 text-muted-foreground">Or continue with</span>
            </div>
          </div>

          {/* Custom Login Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name">Name</Label>
              <Input
                id="name"
                placeholder="Your name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                placeholder="you@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>
            <div className="flex items-center space-x-2">
              <input
                type="checkbox"
                id="admin"
                checked={isAdmin}
                onChange={(e) => setIsAdmin(e.target.checked)}
                className="rounded border-gray-300"
              />
              <Label htmlFor="admin" className="text-sm font-normal">
                Login as Admin (CEO)
              </Label>
            </div>
            <Button type="submit" className="w-full" disabled={login.isPending}>
              {login.isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              Sign In
            </Button>
          </form>

          <p className="text-xs text-center text-muted-foreground">
            This is a demo login. In production, you would integrate with your OAuth provider.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
