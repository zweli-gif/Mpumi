import type { Request, Response } from "express";
import { getUserByOpenId } from "./db";
import type { User } from "./schema";

export interface Context {
  req: Request;
  res: Response;
  user: User | null;
}

export async function createContext({ req, res }: { req: Request; res: Response }): Promise<Context> {
  let user: User | null = null;
  
  // Check for session cookie
  const sessionId = req.cookies?.auth_session;
  if (sessionId) {
    user = (await getUserByOpenId(sessionId)) ?? null;
  }
  
  return { req, res, user };
}
