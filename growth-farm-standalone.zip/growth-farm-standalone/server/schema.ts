import { sqliteTable, text, integer, real } from "drizzle-orm/sqlite-core";

/**
 * Core user table backing auth flow.
 * Extended with health tracking fields.
 */
export const users = sqliteTable("users", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  openId: text("openId").notNull().unique(),
  name: text("name"),
  email: text("email"),
  loginMethod: text("loginMethod"),
  role: text("role", { enum: ["user", "admin"] }).default("user").notNull(),
  avatarUrl: text("avatarUrl"),
  jobTitle: text("jobTitle"),
  currentHealthScore: integer("currentHealthScore").default(75),
  currentEnergyLevel: text("currentEnergyLevel", { enum: ["High", "Med", "Low"] }).default("Med"),
  createdAt: integer("createdAt", { mode: "timestamp" }).$defaultFn(() => new Date()),
  updatedAt: integer("updatedAt", { mode: "timestamp" }).$defaultFn(() => new Date()),
  lastSignedIn: integer("lastSignedIn", { mode: "timestamp" }).$defaultFn(() => new Date()),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Team health check-ins - historical tracking
 */
export const healthCheckins = sqliteTable("healthCheckins", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  userId: integer("userId").notNull(),
  score: integer("score").notNull(), // 0-100
  mood: text("mood", { enum: ["happy", "neutral", "sad"] }).notNull(),
  energyLevel: text("energyLevel", { enum: ["High", "Med", "Low"] }).notNull(),
  notes: text("notes"),
  checkinDate: integer("checkinDate", { mode: "timestamp" }).notNull(),
  createdAt: integer("createdAt", { mode: "timestamp" }).$defaultFn(() => new Date()),
});

export type HealthCheckin = typeof healthCheckins.$inferSelect;
export type InsertHealthCheckin = typeof healthCheckins.$inferInsert;

/**
 * Weekly priorities - max 5 per person per week
 */
export const weeklyPriorities = sqliteTable("weeklyPriorities", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  userId: integer("userId").notNull(),
  description: text("description").notNull(),
  status: text("status", { enum: ["pending", "in-progress", "done", "blocked"] }).default("pending").notNull(),
  dueDate: integer("dueDate", { mode: "timestamp" }).notNull(),
  weekNumber: integer("weekNumber").notNull(), // ISO week number
  year: integer("year").notNull(),
  linkedGoalId: integer("linkedGoalId"), // Optional link to annual goal
  strategicObjective: text("strategicObjective"), // Strategic objective name
  createdAt: integer("createdAt", { mode: "timestamp" }).$defaultFn(() => new Date()),
  updatedAt: integer("updatedAt", { mode: "timestamp" }).$defaultFn(() => new Date()),
});

export type WeeklyPriority = typeof weeklyPriorities.$inferSelect;
export type InsertWeeklyPriority = typeof weeklyPriorities.$inferInsert;

/**
 * Celebrations feed - team wins and milestones
 */
export const celebrations = sqliteTable("celebrations", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  title: text("title").notNull(),
  description: text("description"),
  category: text("category", { enum: ["deal", "birthday", "milestone", "project", "personal"] }).notNull(),
  icon: text("icon").default("🎉"),
  celebrationDate: integer("celebrationDate", { mode: "timestamp" }).notNull(),
  createdBy: integer("createdBy").notNull(),
  taggedUsers: text("taggedUsers"), // JSON array of user IDs
  createdAt: integer("createdAt", { mode: "timestamp" }).$defaultFn(() => new Date()),
});

export type Celebration = typeof celebrations.$inferSelect;
export type InsertCelebration = typeof celebrations.$inferInsert;

/**
 * Pipeline stages configuration for all 6 categories
 */
export const pipelineStages = sqliteTable("pipelineStages", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  pipelineType: text("pipelineType", { enum: ["bd", "ventures", "studio", "clients", "finance", "admin"] }).notNull(),
  name: text("name").notNull(),
  order: integer("order").notNull(),
  probabilityWeight: integer("probabilityWeight").default(0), // For weighted pipeline calculations (0-100)
  color: text("color"), // For visual differentiation
  createdAt: integer("createdAt", { mode: "timestamp" }).$defaultFn(() => new Date()),
});

export type PipelineStage = typeof pipelineStages.$inferSelect;
export type InsertPipelineStage = typeof pipelineStages.$inferInsert;

/**
 * Pipeline cards - items in Kanban boards
 */
export const pipelineCards = sqliteTable("pipelineCards", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  stageId: integer("stageId").notNull(),
  title: text("title").notNull(),
  description: text("description"),
  value: text("value"), // Stored as text for decimal precision
  currency: text("currency").default("ZAR"),
  ownerId: integer("ownerId"),
  dueDate: integer("dueDate", { mode: "timestamp" }),
  tags: text("tags"), // JSON array of tags
  metadata: text("metadata"), // JSON for flexible additional data
  position: integer("position").default(0), // For ordering within stage
  createdAt: integer("createdAt", { mode: "timestamp" }).$defaultFn(() => new Date()),
  updatedAt: integer("updatedAt", { mode: "timestamp" }).$defaultFn(() => new Date()),
  movedAt: integer("movedAt", { mode: "timestamp" }), // Last time card moved stages
});

export type PipelineCard = typeof pipelineCards.$inferSelect;
export type InsertPipelineCard = typeof pipelineCards.$inferInsert;

/**
 * Annual goals - strategic objectives for the year
 */
export const annualGoals = sqliteTable("annualGoals", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  category: text("category", { enum: ["revenue", "ventures", "studio", "clients", "finance", "team", "admin"] }).notNull(),
  description: text("description").notNull(),
  targetValue: text("targetValue").notNull(), // Stored as text for decimal precision
  targetUnit: text("targetUnit").notNull(), // e.g., "ZAR", "count", "percentage"
  ownerId: integer("ownerId").notNull(),
  year: integer("year").notNull(),
  distributionStrategy: text("distributionStrategy", { enum: ["linear", "custom", "historical", "milestone"] }).default("linear").notNull(),
  createdAt: integer("createdAt", { mode: "timestamp" }).$defaultFn(() => new Date()),
  updatedAt: integer("updatedAt", { mode: "timestamp" }).$defaultFn(() => new Date()),
});

export type AnnualGoal = typeof annualGoals.$inferSelect;
export type InsertAnnualGoal = typeof annualGoals.$inferInsert;

/**
 * Monthly targets - cascaded from annual goals
 */
export const monthlyTargets = sqliteTable("monthlyTargets", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  goalId: integer("goalId").notNull(),
  month: integer("month").notNull(), // 1-12
  year: integer("year").notNull(),
  targetValue: text("targetValue").notNull(),
  actualValue: text("actualValue").default("0"),
  weight: text("weight"), // Percentage weight for custom distribution
  rationale: text("rationale"), // Explanation for the target
  notes: text("notes"),
  createdAt: integer("createdAt", { mode: "timestamp" }).$defaultFn(() => new Date()),
  updatedAt: integer("updatedAt", { mode: "timestamp" }).$defaultFn(() => new Date()),
});

export type MonthlyTarget = typeof monthlyTargets.$inferSelect;
export type InsertMonthlyTarget = typeof monthlyTargets.$inferInsert;

/**
 * Performance snapshots - for trend analysis
 */
export const performanceSnapshots = sqliteTable("performanceSnapshots", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  metricName: text("metricName").notNull(),
  metricCategory: text("metricCategory", { enum: ["revenue", "pipeline", "ventures", "clients", "finance", "team", "admin"] }).notNull(),
  value: text("value").notNull(),
  unit: text("unit"),
  snapshotDate: integer("snapshotDate", { mode: "timestamp" }).notNull(),
  metadata: text("metadata"), // JSON for additional context
  createdAt: integer("createdAt", { mode: "timestamp" }).$defaultFn(() => new Date()),
});

export type PerformanceSnapshot = typeof performanceSnapshots.$inferSelect;
export type InsertPerformanceSnapshot = typeof performanceSnapshots.$inferInsert;

/**
 * Automated insights - generated analysis for trends
 */
export const insights = sqliteTable("insights", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  metricName: text("metricName").notNull(),
  insightType: text("insightType", { enum: ["working", "challenge", "recommendation"] }).notNull(),
  content: text("content").notNull(),
  priority: text("priority", { enum: ["low", "medium", "high"] }).default("medium"),
  generatedAt: integer("generatedAt", { mode: "timestamp" }).notNull(),
  validUntil: integer("validUntil", { mode: "timestamp" }), // Optional expiry for time-sensitive insights
  metadata: text("metadata"), // JSON for supporting data
  createdAt: integer("createdAt", { mode: "timestamp" }).$defaultFn(() => new Date()),
});

export type Insight = typeof insights.$inferSelect;
export type InsertInsight = typeof insights.$inferInsert;

/**
 * Activity log - real-time tracking of all actions
 */
export const activityLog = sqliteTable("activityLog", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  userId: integer("userId").notNull(),
  actionType: text("actionType", { enum: [
    "card_moved", 
    "card_created", 
    "card_updated", 
    "priority_added", 
    "priority_completed", 
    "health_checkin", 
    "celebration_added",
    "goal_created",
    "goal_updated",
    "target_updated"
  ] }).notNull(),
  entityType: text("entityType").notNull(), // e.g., "pipeline_card", "weekly_priority"
  entityId: integer("entityId").notNull(),
  oldValue: text("oldValue"), // JSON snapshot of previous state
  newValue: text("newValue"), // JSON snapshot of new state
  description: text("description"), // Human-readable description
  timestamp: integer("timestamp").notNull(), // Unix timestamp in milliseconds
  createdAt: integer("createdAt", { mode: "timestamp" }).$defaultFn(() => new Date()),
});

export type ActivityLog = typeof activityLog.$inferSelect;
export type InsertActivityLog = typeof activityLog.$inferInsert;

/**
 * Dashboard metrics cache - for quick snapshot display
 */
export const dashboardMetrics = sqliteTable("dashboardMetrics", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  metricKey: text("metricKey").notNull().unique(),
  metricValue: text("metricValue").notNull(), // JSON for flexible structure
  lastCalculated: integer("lastCalculated", { mode: "timestamp" }).notNull(),
  expiresAt: integer("expiresAt", { mode: "timestamp" }), // Optional TTL for cache invalidation
  updatedAt: integer("updatedAt", { mode: "timestamp" }).$defaultFn(() => new Date()),
});

export type DashboardMetric = typeof dashboardMetrics.$inferSelect;
export type InsertDashboardMetric = typeof dashboardMetrics.$inferInsert;

/**
 * System settings - configuration for the application
 */
export const systemSettings = sqliteTable("systemSettings", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  settingKey: text("settingKey").notNull().unique(),
  settingValue: text("settingValue").notNull(),
  settingType: text("settingType", { enum: ["string", "number", "boolean", "json"] }).default("string").notNull(),
  description: text("description"),
  updatedBy: integer("updatedBy"),
  updatedAt: integer("updatedAt", { mode: "timestamp" }).$defaultFn(() => new Date()),
});

export type SystemSetting = typeof systemSettings.$inferSelect;
export type InsertSystemSetting = typeof systemSettings.$inferInsert;

/**
 * CEO Weekly Reflections - Top of mind from CEO this week
 */
export const ceoReflections = sqliteTable("ceoReflections", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  content: text("content").notNull(), // Max ~10 lines of text
  weekNumber: integer("weekNumber").notNull(), // ISO week number
  year: integer("year").notNull(),
  createdBy: integer("createdBy").notNull(), // CEO user ID
  createdAt: integer("createdAt", { mode: "timestamp" }).$defaultFn(() => new Date()),
  updatedAt: integer("updatedAt", { mode: "timestamp" }).$defaultFn(() => new Date()),
});

export type CeoReflection = typeof ceoReflections.$inferSelect;
export type InsertCeoReflection = typeof ceoReflections.$inferInsert;
