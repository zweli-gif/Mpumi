export const COOKIE_NAME = "auth_session";
export const ONE_YEAR_MS = 1000 * 60 * 60 * 24 * 365;
